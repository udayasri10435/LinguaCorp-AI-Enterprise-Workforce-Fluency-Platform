import { GoogleGenAI } from '@google/genai';
import type { IncomingMessage, ServerResponse } from 'http';

let aiClient: GoogleGenAI | null = null;

function getAiClient(): GoogleGenAI | null {
  if (!aiClient) {
    const apiKey = process.env.GEMINI_API_KEY;
    if (apiKey) {
      aiClient = new GoogleGenAI({ apiKey });
    }
  }
  return aiClient;
}

// Helper to parse JSON body from incoming Node request
function parseBody(req: IncomingMessage): Promise<any> {
  return new Promise((resolve, reject) => {
    let body = '';
    req.on('data', (chunk) => {
      body += chunk;
      if (body.length > 2 * 1024 * 1024) {
        // 2MB limit
        reject(new Error('Payload too large'));
      }
    });
    req.on('end', () => {
      try {
        resolve(body ? JSON.parse(body) : {});
      } catch (err) {
        reject(new Error('Invalid JSON'));
      }
    });
    req.on('error', reject);
  });
}

function sendJson(res: ServerResponse, statusCode: number, data: any) {
  res.statusCode = statusCode;
  res.setHeader('Content-Type', 'application/json');
  res.end(JSON.stringify(data));
}

export async function handleApiRequest(req: IncomingMessage, res: ServerResponse): Promise<boolean> {
  const url = req.url || '';
  if (!url.startsWith('/api/')) {
    return false;
  }

  // CORS headers if needed
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');

  if (req.method === 'OPTIONS') {
    res.statusCode = 204;
    res.end();
    return true;
  }

  try {
    if (url === '/api/health' && req.method === 'GET') {
      sendJson(res, 200, {
        status: 'ok',
        hasGeminiKey: !!process.env.GEMINI_API_KEY,
        service: 'LinguaCorp AI Enterprise API',
        timestamp: new Date().toISOString(),
      });
      return true;
    }

    if (url === '/api/tutor/chat' && req.method === 'POST') {
      const body = await parseBody(req);
      const {
        scenarioTitle,
        counterpartName,
        counterpartRole,
        companyContext,
        targetLanguage,
        targetLevel,
        conversationHistory,
        userMessage,
        specialInstruction,
      } = body;

      const ai = getAiClient();

      if (!ai) {
        // High-quality contextual fallback when API key is not yet set
        const mockResponse = generateFallbackTutorResponse({
          scenarioTitle,
          counterpartName,
          counterpartRole,
          targetLanguage,
          userMessage,
        });
        sendJson(res, 200, mockResponse);
        return true;
      }

      const prompt = `You are playing the role of ${counterpartName}, ${counterpartRole} at ${companyContext}.
The scenario is: "${scenarioTitle}".
Target Language: ${targetLanguage}. Target Fluency Standard: ${targetLevel} (CEFR standard).
Specific Instructions: ${specialInstruction || 'Be a realistic, sharp enterprise professional. Challenge the user realistically, demand precision, but remain professional.'}

Conversation history so far:
${JSON.stringify(conversationHistory || [], null, 2)}

The user (an enterprise professional learning to communicate at C-suite/executive level) just said:
"${userMessage}"

Respond in the target language (${targetLanguage}) as your character (${counterpartName}).
Also evaluate the user's utterance in English for enterprise performance.

Provide your response strictly in the following JSON format without Markdown code fences:
{
  "reply": "Your character's response in ${targetLanguage}",
  "replyTranslation": "English translation of your reply",
  "audioTone": "analytical | assertive | diplomatic | warm | cautious",
  "evaluation": {
    "overallScore": 88,
    "cefrDetected": "C1",
    "tone": "Formal & Diplomatic",
    "toneScore": 90,
    "strengths": ["Clear articulation of commercial terms", "Appropriate softening phrase"],
    "improvements": ["Could tighten the transition into the pricing defense"],
    "executiveRephrase": "How a seasoned C-level executive would say this in ${targetLanguage}: ...",
    "culturalNuance": "Crucial cultural context about how business counterparts in this region react to this phrasing",
    "keyVocabulary": [
      {
        "term": "Term in ${targetLanguage}",
        "definition": "Definition in business English",
        "example": "Sample business usage"
      }
    ]
  }
}`;

      const aiResponse = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: prompt,
        config: {
          temperature: 0.6,
          responseMimeType: 'application/json',
        },
      });

      const text = aiResponse.text || '{}';
      try {
        const parsed = JSON.parse(text);
        sendJson(res, 200, parsed);
      } catch {
        // Clean markdown backticks if any
        const cleaned = text.replace(/```json\n?/g, '').replace(/```\n?/g, '').trim();
        const parsed = JSON.parse(cleaned);
        sendJson(res, 200, parsed);
      }
      return true;
    }

    if (url === '/api/scenario/generate' && req.method === 'POST') {
      const body = await parseBody(req);
      const { industry, difficulty, counterpartRole, businessGoal, targetLanguage } = body;

      const ai = getAiClient();
      if (!ai) {
        sendJson(res, 200, generateFallbackCustomScenario(body));
        return true;
      }

      const prompt = `Create a high-stakes enterprise business language learning simulation for global enterprise employees.
Industry: ${industry || 'Enterprise SaaS & Cloud Infrastructure'}
Target Language: ${targetLanguage || 'Japanese'}
Target Fluency: ${difficulty || 'C1 Executive'}
Counterpart Role: ${counterpartRole || 'Chief Risk Officer'}
Business Objective: ${businessGoal || 'Negotiate an enterprise contract dispute without discounting more than 5%'}

Respond strictly with a JSON object with this schema:
{
  "id": "scenario-custom-${Date.now()}",
  "title": "A crisp, compelling corporate scenario title",
  "industry": "${industry}",
  "targetLanguage": "${targetLanguage}",
  "level": "${difficulty}",
  "estimatedTime": "15-20 min",
  "counterpart": {
    "name": "Full name appropriate for culture",
    "title": "${counterpartRole}",
    "company": "Fictional multinational company name",
    "personality": "Direct, data-driven, protective of corporate budget",
    "avatar": "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=300&q=80"
  },
  "businessContext": "Detailed 2-sentence background of the commercial stakes",
  "learningObjectives": [
    "Specific high-stakes communication objective 1",
    "Specific high-stakes communication objective 2",
    "Specific cultural/regional business etiquette objective 3"
  ],
  "initialCounterpartMessage": "Opening message in target language challenging the user",
  "initialTranslation": "English translation of opening message",
  "suggestedReplies": [
    "Suggested diplomatic response in target language",
    "Suggested assertive response in target language"
  ],
  "keyVocabulary": [
    {"term": "Term", "reading": "Phonetic/Romaji if applicable", "meaning": "English meaning", "usage": "Corporate context"}
  ]
}`;

      const aiResponse = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: prompt,
        config: {
          temperature: 0.7,
          responseMimeType: 'application/json',
        },
      });

      const text = aiResponse.text || '{}';
      try {
        const parsed = JSON.parse(text);
        sendJson(res, 200, parsed);
      } catch {
        const cleaned = text.replace(/```json\n?/g, '').replace(/```\n?/g, '').trim();
        sendJson(res, 200, JSON.parse(cleaned));
      }
      return true;
    }

    sendJson(res, 404, { error: 'Endpoint not found' });
    return true;
  } catch (error: any) {
    console.error('API Error:', error);
    sendJson(res, 500, {
      error: error.message || 'Internal server error',
    });
    return true;
  }
}

function generateFallbackTutorResponse(params: {
  scenarioTitle?: string;
  counterpartName?: string;
  counterpartRole?: string;
  targetLanguage?: string;
  userMessage?: string;
}) {
  const lang = params.targetLanguage?.toLowerCase() || 'english';
  const role = params.counterpartRole || 'Vice President of Procurement';
  const name = params.counterpartName || 'Director';

  if (lang.includes('japan')) {
    return {
      reply: 'ご提案いただいた内容の重要性は理解しておりますが、弊社の取締役会としてはROIの回収期間について懸念を抱いております。この点について、リスクヘッジの観点からどのようにご説明いただけますでしょうか？',
      replyTranslation: 'I understand the significance of your proposal; however, our board of directors holds concerns regarding the payback period on ROI. From a risk-hedging perspective, how do you explain this point?',
      audioTone: 'cautious',
      evaluation: {
        overallScore: 88,
        cefrDetected: 'C1',
        tone: 'Executive Keigo & Diplomatic',
        toneScore: 92,
        strengths: [
          'Excellent use of formal sonkeigo/kenjougo softening particles',
          'Avoided direct confrontation while maintaining the commercial value proposition',
        ],
        improvements: [
          'Consider preempting the Nemawashi (consensus-building) process in your next rebuttal',
        ],
        executiveRephrase: '恐縮ではございますが、弊社といたしましては御社の事業拡大に即応した段階的コミットメントをご提案可能でございます。',
        culturalNuance: 'In Japanese boardroom negotiation, framing concession as "protecting mutual risk" preserves face and accelerates senior stakeholder consensus.',
        keyVocabulary: [
          {
            term: '根回し (Nemawashi)',
            definition: 'Informal preliminary consensus-building behind the scenes before an official vote',
            example: '本件の承認をスムーズにするため、事前に各本部長への根回しを進めております。',
          },
          {
            term: 'リスクヘッジ (Risuku Hejji)',
            definition: 'Risk hedging / operational mitigation',
            example: '複数拠点の同時稼働により、リスクヘッジを図る方針です。',
          },
        ],
      },
    };
  }

  if (lang.includes('german')) {
    return {
      reply: 'Ihre Zahlen sind zwar nachvollziehbar, aber unsere Rechtsabteilung verlangt bezüglich der DSGVO-Haftungsklausel und der 99.99% SLA-Garantie eindeutigere Zusicherungen. Können Sie diese vertraglich fixieren?',
      replyTranslation: 'Your numbers are comprehensible; however, our legal department demands clearer assurances regarding the GDPR liability clause and the 99.99% SLA guarantee. Can you anchor these contractually?',
      audioTone: 'assertive',
      evaluation: {
        overallScore: 85,
        cefrDetected: 'C1',
        tone: 'Precise & Direct Corporate German',
        toneScore: 89,
        strengths: [
          'Logical structure with quantifiable data points',
          'Proper German corporate terminology (Haftung, SLA-Garantie)',
        ],
        improvements: [
          'Directly cite the DIN/ISO compliance protocol to satisfy German engineering skepticism',
        ],
        executiveRephrase: 'Selbstverständlich sind wir bereit, die geforderten SLA-Parametern als verbindliche Anlage im Hauptvertrag zu verankern.',
        culturalNuance: 'German enterprise executives value technical precision and contractual explicitness over ambiguous goodwill gestures.',
        keyVocabulary: [
          {
            term: 'die Haftungsklausel',
            definition: 'Liability / indemnification clause',
            example: 'Die Haftungsklausel deckt Betriebsunterbrechungen vollständig ab.',
          },
          {
            term: 'verbindlich verankern',
            definition: 'To legally / bindingly anchor in an agreement',
            example: 'Wir möchten diese Qualitätsstandards verbindlich verankern.',
          },
        ],
      },
    };
  }

  if (lang.includes('mandarin') || lang.includes('chinese')) {
    return {
      reply: '张总，贵公司的技术架构我们非常认可。不过在交付周期和本地化运维支持方面，我们总部需要看到更确定的SLA承诺。您看我们能否在备忘录中单独列出专项响应团队？',
      replyTranslation: 'Director Zhang, we highly recognize your company’s technical architecture. However, regarding delivery cycles and local operations support, our headquarters requires firmer SLA commitments. Could we specify a dedicated response team in the MoU?',
      audioTone: 'diplomatic',
      evaluation: {
        overallScore: 91,
        cefrDetected: 'C1',
        tone: 'Executive Strategic Partnership',
        toneScore: 94,
        strengths: [
          'Demonstrated high respect for executive status while proposing concrete structural solutions',
          'Good balance of relationship (Guanxi) warmth and strict commercial boundary',
        ],
        improvements: [
          'You can mention reciprocal benefits for their upcoming fiscal year expansion',
        ],
        executiveRephrase: '理解贵部的战略部署，我们完全可以在谅解备忘录中明确设立双语专项应急保障小组。',
        culturalNuance: 'In Chinese enterprise discussions, validating the counterpart’s stature before introducing a mutual memorandum (MOU) builds deep trust.',
        keyVocabulary: [
          {
            term: '谅解备忘录 (Liàngjiě Bèiwànglù)',
            definition: 'Memorandum of Understanding (MOU)',
            example: '双方已于上周签署了战略合作谅解备忘录。',
          },
          {
            term: '本地化运维 (Běndìhuà Yùnwéi)',
            definition: 'Localized DevOps and operational support',
            example: '我们提供7x24小时全中文本地化运维保障。',
          },
        ],
      },
    };
  }

  // Default English / Global Business
  return {
    reply: `I see the architectural merit in your proposal. However, our investment committee has raised red flags regarding the 18-month payback horizon and the migration risk. How does your enterprise SLA guarantee business continuity during phase one?`,
    replyTranslation: 'Direct statement on enterprise SLA continuity during transition.',
    audioTone: 'analytical',
    evaluation: {
      overallScore: 89,
      cefrDetected: 'C1',
      tone: 'Boardroom Strategic & Data-Driven',
      toneScore: 91,
      strengths: [
        'Strong executive presence and commercial vocabulary',
        'Directly addressed the ROI bottleneck without defensive hedging',
      ],
      improvements: [
        'Frame the phase one risk in terms of customer retention upside rather than mere cost avoidance',
      ],
      executiveRephrase: 'To mitigate transition exposure, we back phase one with a zero-downtime cutover guarantee tied to liquidated damages.',
      culturalNuance: 'Global investment committees respond best when enterprise vendors share balance-sheet skin in the game through performance warranties.',
      keyVocabulary: [
        {
          term: 'Liquidated Damages',
          definition: 'Predetermined contractual compensation for specific delivery delays or breaches',
          example: 'We accepted a standard liquidated damages cap to de-risk the customer onboarding.',
        },
        {
          term: 'Payback Horizon',
          definition: 'The time required for cumulative cash inflows to equal initial capital expenditure',
          example: 'Our board mandates a payback horizon under 14 months for all SaaS acquisitions.',
        },
      ],
    },
  };
}

function generateFallbackCustomScenario(body: any) {
  return {
    id: `scenario-custom-${Date.now()}`,
    title: `Cross-Border ${body.industry || 'Enterprise'} Strategic Alignment`,
    industry: body.industry || 'Technology & Cloud',
    targetLanguage: body.targetLanguage || 'Japanese',
    level: body.difficulty || 'C1 Executive',
    estimatedTime: '15-20 min',
    counterpart: {
      name: body.counterpartRole ? `Kenji Sato (${body.counterpartRole})` : 'Kenji Sato',
      title: body.counterpartRole || 'Managing Director of Global Sourcing',
      company: 'Sumitomo Global Technologies',
      personality: 'Methodical, risk-averse, highly attentive to long-term vendor stability',
      avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=300&q=80',
    },
    businessContext: `Your enterprise is pitching a multimillion-dollar core system modernization. The counterpart's executive board is concerned about operational disruption and contract liability caps.`,
    learningObjectives: [
      'Master diplomatic counter-proposals that preserve vendor margin',
      'Defend contractual SLA commitments using native industry terminology',
      'Navigate senior hierarchy etiquette and indirect disagreement protocols',
    ],
    initialCounterpartMessage: '本提案の技術的優位性は拝見しましたが、初期導入フェーズにおけるダウンタイムリスクに関する補償条項が不十分に感じられます。',
    initialTranslation: 'We have seen the technical advantages of your proposal, but the compensation clauses regarding downtime risk during the initial rollout appear insufficient.',
    suggestedReplies: [
      'ダウンタイムに対する段階的補償プログラムをご用意しておりますので、詳細をご説明いたします。',
      '万全を期すため、並行稼働期間を設けてリスクをゼロに近づける移行計画をご提示可能です。',
    ],
    keyVocabulary: [
      {
        term: '補償条項 (Hoshou Joukou)',
        reading: 'Indemnification / Compensation clause',
        meaning: 'Legal stipulation governing vendor liability for downtime',
        usage: '契約書に補償条項の上限を設定する。',
      },
    ],
  };
}
