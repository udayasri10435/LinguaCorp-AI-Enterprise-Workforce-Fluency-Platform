export type CEFRLevel = 'A2' | 'B1' | 'B2' | 'C1' | 'C2';

export interface CounterpartProfile {
  name: string;
  title: string;
  company: string;
  personality: string;
  avatar: string;
  voiceGender?: 'male' | 'female';
}

export interface VocabularyItem {
  term: string;
  reading?: string;
  meaning: string;
  usage?: string;
  industry?: string;
}

export interface EnterpriseScenario {
  id: string;
  title: string;
  subtitle: string;
  industry: 'FinTech & Banking' | 'Tech & Cloud SaaS' | 'BioPharma & MedTech' | 'Global Supply Chain' | 'M&A & Corporate Legal' | 'Aerospace & Heavy Industry';
  targetLanguage: 'Japanese' | 'German' | 'Mandarin' | 'Business English' | 'Spanish' | 'French';
  level: CEFRLevel;
  difficultyTag: 'Executive C-Suite' | 'High-Stakes Negotiation' | 'Crisis & Escalation' | 'Board Presentation' | 'Deal Due Diligence';
  estimatedMinutes: number;
  counterpart: CounterpartProfile;
  businessContext: string;
  hiddenStakes: string;
  learningObjectives: string[];
  culturalProtocol: string;
  initialCounterpartMessage: string;
  initialTranslation: string;
  suggestedReplies: {
    type: 'Diplomatic Softening' | 'Firm Negotiation' | 'Data-Driven Rebuttal';
    text: string;
    translation: string;
  }[];
  keyVocabulary: VocabularyItem[];
}

export interface EvaluationResult {
  overallScore: number;
  cefrDetected: CEFRLevel;
  tone: string;
  toneScore: number;
  strengths: string[];
  improvements: string[];
  executiveRephrase: string;
  culturalNuance: string;
  keyVocabulary: {
    term: string;
    definition: string;
    example: string;
  }[];
}

export interface DialogTurn {
  id: string;
  sender: 'ai' | 'user';
  text: string;
  translation?: string;
  timestamp: string;
  audioTone?: string;
  evaluation?: EvaluationResult;
}

export interface DepartmentMetric {
  department: string;
  headCount: number;
  activeRate: number;
  fluencyScore: number;
  cefrMedian: CEFRLevel;
  negotiationMastery: number; // 0-100
  presentationMastery: number;
  technicalPrecision: number;
  dealVelocityImpact: string;
}

export interface RegionalMetric {
  region: string;
  city: string;
  flag: string;
  seats: number;
  fluencyAverage: number;
  primaryTrack: string;
  changeRate: string;
}

export interface EnterpriseLearner {
  id: string;
  name: string;
  avatar: string;
  role: string;
  department: string;
  location: string;
  targetLanguage: string;
  currentLevel: CEFRLevel;
  targetLevel: CEFRLevel;
  streakDays: number;
  totalHours: number;
  scenariosCompleted: number;
  overallFluencyScore: number;
  lastActive: string;
}

export interface LexiconFlashcard {
  id: string;
  term: string;
  phonetic?: string;
  targetLanguage: string;
  translation: string;
  industry: string;
  contextSentence: string;
  contextTranslation: string;
  executiveTip: string;
  mastered: boolean;
}

export interface EnterpriseCertification {
  id: string;
  title: string;
  code: string;
  issuer: string;
  level: CEFRLevel;
  score: number;
  issuedDate: string;
  expiresDate: string;
  verificationHash: string;
  skillsVerified: string[];
}
