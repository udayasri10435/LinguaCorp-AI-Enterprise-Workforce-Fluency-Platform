// Audio and Speech Utilities for Enterprise Language Simulation

export function speakText(text: string, language: string, onEnd?: () => void): () => void {
  if (typeof window === 'undefined' || !('speechSynthesis' in window)) {
    if (onEnd) onEnd();
    return () => {};
  }

  // Cancel any ongoing speech
  window.speechSynthesis.cancel();

  const utterance = new SpeechSynthesisUtterance(text);

  // Map language string to BCP 47 code
  const langLower = language.toLowerCase();
  let langCode = 'en-US';
  if (langLower.includes('japan')) langCode = 'ja-JP';
  else if (langLower.includes('german')) langCode = 'de-DE';
  else if (langLower.includes('mandarin') || langLower.includes('chinese')) langCode = 'zh-CN';
  else if (langLower.includes('spanish')) langCode = 'es-ES';
  else if (langLower.includes('french')) langCode = 'fr-FR';

  utterance.lang = langCode;
  utterance.rate = 0.95; // Slightly measured executive cadence
  utterance.pitch = 1.0;

  // Try finding native voice
  const voices = window.speechSynthesis.getVoices();
  const matchedVoice = voices.find((v) => v.lang.startsWith(langCode.substring(0, 2)));
  if (matchedVoice) {
    utterance.voice = matchedVoice;
  }

  if (onEnd) {
    utterance.onend = () => onEnd();
    utterance.onerror = () => onEnd();
  }

  window.speechSynthesis.speak(utterance);

  return () => {
    window.speechSynthesis.cancel();
  };
}

export function stopSpeaking() {
  if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
    window.speechSynthesis.cancel();
  }
}

export function isSpeechRecognitionSupported(): boolean {
  if (typeof window === 'undefined') return false;
  return 'webkitSpeechRecognition' in window || 'SpeechRecognition' in window;
}

export interface SpeechRecognitionController {
  start: () => void;
  stop: () => void;
}

export function createSpeechRecognizer(
  language: string,
  onResult: (transcript: string) => void,
  onError: (error: string) => void,
  onStateChange: (isListening: boolean) => void
): SpeechRecognitionController | null {
  if (typeof window === 'undefined') return null;

  const SpeechRecognitionClass = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
  if (!SpeechRecognitionClass) return null;

  const recognizer = new SpeechRecognitionClass();
  recognizer.continuous = false;
  recognizer.interimResults = true;

  const langLower = language.toLowerCase();
  let langCode = 'en-US';
  if (langLower.includes('japan')) langCode = 'ja-JP';
  else if (langLower.includes('german')) langCode = 'de-DE';
  else if (langLower.includes('mandarin') || langLower.includes('chinese')) langCode = 'zh-CN';
  else if (langLower.includes('spanish')) langCode = 'es-ES';
  else if (langLower.includes('french')) langCode = 'fr-FR';

  recognizer.lang = langCode;

  recognizer.onstart = () => {
    onStateChange(true);
  };

  recognizer.onresult = (event: any) => {
    let interim = '';
    let final = '';
    for (let i = event.resultIndex; i < event.results.length; ++i) {
      if (event.results[i].isFinal) {
        final += event.results[i][0].transcript;
      } else {
        interim += event.results[i][0].transcript;
      }
    }
    const current = final || interim;
    if (current) {
      onResult(current);
    }
  };

  recognizer.onerror = (event: any) => {
    console.warn('Speech recognition error:', event.error);
    onError(event.error);
    onStateChange(false);
  };

  recognizer.onend = () => {
    onStateChange(false);
  };

  return {
    start: () => {
      try {
        recognizer.start();
      } catch (err) {
        console.warn('Recognizer already started or failed', err);
      }
    },
    stop: () => {
      try {
        recognizer.stop();
      } catch (err) {
        console.warn('Recognizer stop failed', err);
      }
    },
  };
}
