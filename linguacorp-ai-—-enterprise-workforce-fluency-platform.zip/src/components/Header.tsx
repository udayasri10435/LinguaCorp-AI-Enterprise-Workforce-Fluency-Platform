import React, { useState } from 'react';
import {
  Globe,
  Building2,
  UserCheck,
  BarChart3,
  Headphones,
  ShieldCheck,
  Sparkles,
  ChevronDown,
  Volume2,
  VolumeX,
} from 'lucide-react';
import { COMPANY_PROFILE } from '../data/enterpriseData.ts';

interface HeaderProps {
  currentView: 'learner' | 'admin';
  onViewChange: (view: 'learner' | 'admin') => void;
  onOpenScenarioModal: () => void;
  onOpenSalesModal: () => void;
  soundEnabled: boolean;
  onToggleSound: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  currentView,
  onViewChange,
  onOpenScenarioModal,
  onOpenSalesModal,
  soundEnabled,
  onToggleSound,
}) => {
  const [selectedTenant, setSelectedTenant] = useState('OmniVanguard Global Holdings');
  const [showTenantMenu, setShowTenantMenu] = useState(false);

  const enterpriseTenants = [
    { name: 'OmniVanguard Global Holdings', seats: '2,500 seats', region: 'Global' },
    { name: 'Siemens Mobility & Rail Systems', seats: '1,400 seats', region: 'EMEA / APAC' },
    { name: 'Nomura Securities International', seats: '3,200 seats', region: 'Tokyo / NY' },
    { name: 'Novartis Pharma Global BioTech', seats: '1,850 seats', region: 'Basel / Boston' },
  ];

  return (
    <header className="sticky top-0 z-40 border-b border-slate-800/80 bg-[#0b0f17]/90 backdrop-blur-md">
      {/* Top Enterprise Security & Trust Banner */}
      <div className="border-b border-slate-850 bg-slate-950/60 px-4 py-1 text-xs text-slate-400">
        <div className="mx-auto flex max-w-7xl items-center justify-between">
          <div className="flex items-center gap-3">
            <span className="flex items-center gap-1.5 text-emerald-400 font-medium">
              <span className="relative flex h-2 w-2">
                <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-emerald-400 opacity-75"></span>
                <span className="relative inline-flex h-2 w-2 rounded-full bg-emerald-500"></span>
              </span>
              Enterprise AI Engine Active
            </span>
            <span className="text-slate-600">|</span>
            <span className="flex items-center gap-1 text-slate-400">
              <ShieldCheck className="h-3.5 w-3.5 text-indigo-400" />
              SOC2 Type II • ISO 27001 • Okta SAML SSO • Data Residency Enforced
            </span>
          </div>

          <div className="flex items-center gap-4">
            <span className="hidden sm:inline text-slate-400">
              Multi-Tenant Instance: <strong className="text-slate-200">Dedicated Sovereign Cloud</strong>
            </span>
            <button
              onClick={onOpenSalesModal}
              className="text-indigo-400 hover:text-indigo-300 font-medium transition-colors"
            >
              Enterprise Licensing & RFP →
            </button>
          </div>
        </div>
      </div>

      {/* Main Navigation Bar */}
      <div className="mx-auto flex max-w-7xl items-center justify-between px-4 py-3 sm:px-6">
        {/* Brand & Organization Switcher */}
        <div className="flex items-center gap-6">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-indigo-500 via-indigo-600 to-blue-700 shadow-lg shadow-indigo-600/20 text-white font-bold text-lg tracking-wider">
              LQ
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-lg font-bold tracking-tight text-white">
                  LinguaCorp<span className="text-indigo-400">AI</span>
                </span>
                <span className="rounded bg-indigo-500/10 px-2 py-0.5 text-[10px] font-semibold tracking-wider text-indigo-300 border border-indigo-500/20 uppercase">
                  Enterprise
                </span>
              </div>
              <p className="text-xs text-slate-400">Global Workforce Fluency & AI Tutor</p>
            </div>
          </div>

          {/* Tenant Switcher dropdown */}
          <div className="relative hidden md:block">
            <button
              onClick={() => setShowTenantMenu(!showTenantMenu)}
              className="flex items-center gap-2 rounded-lg border border-slate-800 bg-slate-900/80 px-3 py-1.5 text-xs text-slate-200 hover:border-slate-700 hover:bg-slate-850 transition-all"
            >
              <Building2 className="h-3.5 w-3.5 text-indigo-400" />
              <span className="max-w-[170px] truncate font-medium">{selectedTenant}</span>
              <ChevronDown className="h-3.5 w-3.5 text-slate-400" />
            </button>

            {showTenantMenu && (
              <div className="absolute left-0 top-full mt-1 w-72 rounded-xl border border-slate-800 bg-slate-900 p-2 shadow-2xl z-50">
                <div className="px-2 py-1 text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
                  Select Corporate Tenant
                </div>
                {enterpriseTenants.map((t) => (
                  <button
                    key={t.name}
                    onClick={() => {
                      setSelectedTenant(t.name);
                      setShowTenantMenu(false);
                    }}
                    className={`w-full text-left rounded-lg px-2.5 py-2 text-xs transition-colors flex items-center justify-between ${
                      selectedTenant === t.name
                        ? 'bg-indigo-600/20 text-indigo-200 border border-indigo-500/30'
                        : 'text-slate-300 hover:bg-slate-800'
                    }`}
                  >
                    <div>
                      <p className="font-medium text-slate-200">{t.name}</p>
                      <p className="text-[10px] text-slate-400">{t.region}</p>
                    </div>
                    <span className="text-[10px] bg-slate-800 text-slate-300 px-1.5 py-0.5 rounded">
                      {t.seats}
                    </span>
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* View Switcher: Learner vs C-Suite / L&D Admin */}
        <div className="flex items-center gap-3">
          <div className="flex items-center rounded-xl bg-slate-900/90 p-1 border border-slate-800">
            <button
              onClick={() => onViewChange('learner')}
              className={`flex items-center gap-2 rounded-lg px-3.5 py-1.5 text-xs font-semibold transition-all ${
                currentView === 'learner'
                  ? 'bg-indigo-600 text-white shadow-sm shadow-indigo-600/30'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <UserCheck className="h-3.5 w-3.5" />
              <span>Learner Workspace</span>
            </button>
            <button
              onClick={() => onViewChange('admin')}
              className={`flex items-center gap-2 rounded-lg px-3.5 py-1.5 text-xs font-semibold transition-all ${
                currentView === 'admin'
                  ? 'bg-indigo-600 text-white shadow-sm shadow-indigo-600/30'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <BarChart3 className="h-3.5 w-3.5" />
              <span>C-Suite Analytics</span>
            </button>
          </div>

          {/* AI Scenario Generator Button */}
          <button
            onClick={onOpenScenarioModal}
            className="hidden lg:flex items-center gap-1.5 rounded-xl border border-indigo-500/30 bg-indigo-500/10 px-3 py-1.5 text-xs font-medium text-indigo-300 hover:bg-indigo-500/20 hover:border-indigo-500/50 transition-all"
            title="Generate custom deal scenario with Gemini AI"
          >
            <Sparkles className="h-3.5 w-3.5 text-indigo-400" />
            <span>Generate Scenario</span>
          </button>

          {/* Sound Toggle */}
          <button
            onClick={onToggleSound}
            className={`rounded-lg p-2 border transition-all ${
              soundEnabled
                ? 'border-indigo-500/30 bg-indigo-500/10 text-indigo-400 hover:bg-indigo-500/20'
                : 'border-slate-800 bg-slate-900 text-slate-500 hover:text-slate-300'
            }`}
            title={soundEnabled ? 'Speech audio enabled' : 'Speech audio muted'}
          >
            {soundEnabled ? <Volume2 className="h-4 w-4" /> : <VolumeX className="h-4 w-4" />}
          </button>

          {/* Enterprise Demo / Sales CTA */}
          <button
            onClick={onOpenSalesModal}
            className="flex items-center gap-2 rounded-xl bg-gradient-to-r from-indigo-500 to-indigo-600 px-3.5 py-1.5 text-xs font-semibold text-white shadow-md shadow-indigo-600/20 hover:from-indigo-600 hover:to-indigo-700 transition-all"
          >
            <Globe className="h-3.5 w-3.5" />
            <span className="hidden sm:inline">Enterprise License</span>
          </button>
        </div>
      </div>
    </header>
  );
};
