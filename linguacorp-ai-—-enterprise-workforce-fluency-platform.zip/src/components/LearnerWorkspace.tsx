import React, { useState } from 'react';
import {
  MessageSquare,
  Activity,
  BookOpen,
  Award,
  Sparkles,
  Flame,
  Clock,
  TrendingUp,
  Target,
  ChevronDown,
  Building2,
  PlusCircle,
} from 'lucide-react';
import { ENTERPRISE_SCENARIOS, SAMPLE_LEARNER } from '../data/enterpriseData.ts';
import { EnterpriseScenario } from '../types/index.ts';
import { RoleplaySimulator } from './RoleplaySimulator.tsx';
import { PronunciationStudio } from './PronunciationStudio.tsx';
import { JargonVault } from './JargonVault.tsx';
import { CertificationView } from './CertificationView.tsx';

interface LearnerWorkspaceProps {
  scenarios: EnterpriseScenario[];
  selectedScenario: EnterpriseScenario;
  onSelectScenario: (scenario: EnterpriseScenario) => void;
  onOpenCustomScenarioModal: () => void;
  soundEnabled: boolean;
}

export const LearnerWorkspace: React.FC<LearnerWorkspaceProps> = ({
  scenarios,
  selectedScenario,
  onSelectScenario,
  onOpenCustomScenarioModal,
  soundEnabled,
}) => {
  const [activeTab, setActiveTab] = useState<'roleplay' | 'pronunciation' | 'jargon' | 'certification'>('roleplay');
  const [showScenarioDropdown, setShowScenarioDropdown] = useState(false);

  return (
    <div className="space-y-6">
      {/* Learner Executive Profile & Stats Header */}
      <div className="rounded-2xl border border-slate-800 bg-gradient-to-r from-slate-900/90 via-slate-900/60 to-slate-950 p-5 shadow-2xl flex flex-col lg:flex-row lg:items-center justify-between gap-5">
        {/* User Card */}
        <div className="flex items-center gap-4">
          <div className="relative">
            <img
              src={SAMPLE_LEARNER.avatar}
              alt={SAMPLE_LEARNER.name}
              className="h-14 w-14 rounded-2xl object-cover border-2 border-indigo-500/40 shadow-lg"
            />
            <span className="absolute -bottom-1 -right-1 h-5 w-5 rounded-full bg-emerald-500 border-2 border-slate-900 flex items-center justify-center text-[10px] font-bold text-white">
              ✓
            </span>
          </div>

          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-lg font-bold text-white">{SAMPLE_LEARNER.name}</h2>
              <span className="rounded-md bg-indigo-500/20 px-2 py-0.5 text-[11px] font-bold text-indigo-300 border border-indigo-500/30">
                {SAMPLE_LEARNER.currentLevel} Senior Executive Track
              </span>
            </div>
            <p className="text-xs text-slate-400 mt-0.5">
              {SAMPLE_LEARNER.role} • <span className="text-slate-300">{SAMPLE_LEARNER.department}</span>
            </p>
          </div>
        </div>

        {/* Executive Stats Badges */}
        <div className="flex flex-wrap items-center gap-3">
          <div className="flex items-center gap-2.5 rounded-xl bg-slate-950/80 px-3.5 py-2 border border-slate-800">
            <Flame className="h-4 w-4 text-amber-400" />
            <div>
              <span className="text-[10px] text-slate-500 uppercase tracking-wider block font-semibold">
                Executive Streak
              </span>
              <span className="text-xs font-bold text-white">{SAMPLE_LEARNER.streakDays} Days</span>
            </div>
          </div>

          <div className="flex items-center gap-2.5 rounded-xl bg-slate-950/80 px-3.5 py-2 border border-slate-800">
            <TrendingUp className="h-4 w-4 text-emerald-400" />
            <div>
              <span className="text-[10px] text-slate-500 uppercase tracking-wider block font-semibold">
                Fluency Score
              </span>
              <span className="text-xs font-bold text-emerald-400">{SAMPLE_LEARNER.overallFluencyScore} / 100</span>
            </div>
          </div>

          <div className="flex items-center gap-2.5 rounded-xl bg-slate-950/80 px-3.5 py-2 border border-slate-800">
            <Clock className="h-4 w-4 text-indigo-400" />
            <div>
              <span className="text-[10px] text-slate-500 uppercase tracking-wider block font-semibold">
                Simulation Time
              </span>
              <span className="text-xs font-bold text-white">{SAMPLE_LEARNER.totalHours} hrs</span>
            </div>
          </div>

          <div className="flex items-center gap-2.5 rounded-xl bg-slate-950/80 px-3.5 py-2 border border-slate-800">
            <Target className="h-4 w-4 text-purple-400" />
            <div>
              <span className="text-[10px] text-slate-500 uppercase tracking-wider block font-semibold">
                Target Milestone
              </span>
              <span className="text-xs font-bold text-purple-300">CEFR {SAMPLE_LEARNER.targetLevel} Mastery</span>
            </div>
          </div>
        </div>
      </div>

      {/* Scenario Selector & Mission Banner */}
      <div className="rounded-2xl border border-slate-800 bg-slate-900/80 p-4 shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="h-10 w-10 rounded-xl bg-indigo-500/10 border border-indigo-500/30 flex items-center justify-center text-indigo-400">
            <Building2 className="h-5 w-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-[10px] font-bold uppercase tracking-wider text-indigo-400 bg-indigo-500/10 px-2 py-0.5 rounded border border-indigo-500/20">
                Active Mission: {selectedScenario.targetLanguage} ({selectedScenario.level})
              </span>
              <span className="text-xs text-slate-500">•</span>
              <span className="text-xs font-medium text-amber-400">
                {selectedScenario.difficultyTag}
              </span>
            </div>
            <h3 className="text-base font-bold text-white mt-0.5">
              {selectedScenario.title}
            </h3>
          </div>
        </div>

        {/* Switch Scenario Dropdown & Generator */}
        <div className="flex items-center gap-2.5">
          <div className="relative">
            <button
              onClick={() => setShowScenarioDropdown(!showScenarioDropdown)}
              className="flex items-center gap-2 rounded-xl border border-slate-700 bg-slate-800 px-3.5 py-2 text-xs font-semibold text-slate-200 hover:bg-slate-750 transition-all"
            >
              <span>Switch Scenario ({scenarios.length})</span>
              <ChevronDown className="h-3.5 w-3.5 text-slate-400" />
            </button>

            {showScenarioDropdown && (
              <div className="absolute right-0 top-full mt-2 w-80 sm:w-96 rounded-2xl border border-slate-800 bg-slate-900 p-2 shadow-2xl z-50">
                <div className="px-3 py-2 text-[11px] font-bold text-slate-400 uppercase tracking-wider border-b border-slate-800">
                  Select Corporate Simulation
                </div>
                <div className="max-h-72 overflow-y-auto space-y-1 py-1">
                  {scenarios.map((sc) => (
                    <button
                      key={sc.id}
                      onClick={() => {
                        onSelectScenario(sc);
                        setShowScenarioDropdown(false);
                      }}
                      className={`w-full text-left p-2.5 rounded-xl text-xs transition-all flex items-start gap-3 ${
                        selectedScenario.id === sc.id
                          ? 'bg-indigo-600/20 text-indigo-200 border border-indigo-500/30'
                          : 'text-slate-300 hover:bg-slate-800'
                      }`}
                    >
                      <img
                        src={sc.counterpart.avatar}
                        alt={sc.counterpart.name}
                        className="h-8 w-8 rounded-lg object-cover border border-slate-700 shrink-0 mt-0.5"
                      />
                      <div className="truncate">
                        <p className="font-semibold text-white truncate">{sc.title}</p>
                        <p className="text-[11px] text-slate-400 mt-0.5">
                          {sc.targetLanguage} • {sc.level} • {sc.counterpart.name}
                        </p>
                      </div>
                    </button>
                  ))}
                </div>

                <div className="p-2 border-t border-slate-800">
                  <button
                    onClick={() => {
                      setShowScenarioDropdown(false);
                      onOpenCustomScenarioModal();
                    }}
                    className="w-full flex items-center justify-center gap-1.5 py-2 rounded-xl bg-indigo-600/20 border border-indigo-500/40 text-xs font-semibold text-indigo-300 hover:bg-indigo-600/30 transition-all"
                  >
                    <PlusCircle className="h-3.5 w-3.5" />
                    <span>Generate Custom Scenario with Gemini</span>
                  </button>
                </div>
              </div>
            )}
          </div>

          <button
            onClick={onOpenCustomScenarioModal}
            className="flex items-center gap-1.5 rounded-xl bg-indigo-600 px-3.5 py-2 text-xs font-semibold text-white shadow-md shadow-indigo-600/20 hover:bg-indigo-500 transition-all"
          >
            <Sparkles className="h-3.5 w-3.5" />
            <span className="hidden sm:inline">AI Scenario Generator</span>
          </button>
        </div>
      </div>

      {/* Tabs Navigation */}
      <div className="border-b border-slate-800 flex items-center gap-2 overflow-x-auto pb-px">
        <button
          onClick={() => setActiveTab('roleplay')}
          className={`flex items-center gap-2 px-4 py-3 text-xs font-semibold border-b-2 transition-all shrink-0 ${
            activeTab === 'roleplay'
              ? 'border-indigo-500 text-white bg-indigo-500/5'
              : 'border-transparent text-slate-400 hover:text-slate-200'
          }`}
        >
          <MessageSquare className="h-4 w-4 text-indigo-400" />
          <span>Interactive AI Executive Roleplay</span>
        </button>

        <button
          onClick={() => setActiveTab('pronunciation')}
          className={`flex items-center gap-2 px-4 py-3 text-xs font-semibold border-b-2 transition-all shrink-0 ${
            activeTab === 'pronunciation'
              ? 'border-indigo-500 text-white bg-indigo-500/5'
              : 'border-transparent text-slate-400 hover:text-slate-200'
          }`}
        >
          <Activity className="h-4 w-4 text-emerald-400" />
          <span>Pronunciation & Cadence Studio</span>
        </button>

        <button
          onClick={() => setActiveTab('jargon')}
          className={`flex items-center gap-2 px-4 py-3 text-xs font-semibold border-b-2 transition-all shrink-0 ${
            activeTab === 'jargon'
              ? 'border-indigo-500 text-white bg-indigo-500/5'
              : 'border-transparent text-slate-400 hover:text-slate-200'
          }`}
        >
          <BookOpen className="h-4 w-4 text-amber-400" />
          <span>Enterprise Jargon Vault</span>
        </button>

        <button
          onClick={() => setActiveTab('certification')}
          className={`flex items-center gap-2 px-4 py-3 text-xs font-semibold border-b-2 transition-all shrink-0 ${
            activeTab === 'certification'
              ? 'border-indigo-500 text-white bg-indigo-500/5'
              : 'border-transparent text-slate-400 hover:text-slate-200'
          }`}
        >
          <Award className="h-4 w-4 text-purple-400" />
          <span>CEFR Corporate Credential</span>
        </button>
      </div>

      {/* Tab Panels */}
      <div>
        {activeTab === 'roleplay' && (
          <RoleplaySimulator
            scenario={selectedScenario}
            soundEnabled={soundEnabled}
          />
        )}
        {activeTab === 'pronunciation' && <PronunciationStudio />}
        {activeTab === 'jargon' && <JargonVault />}
        {activeTab === 'certification' && <CertificationView />}
      </div>
    </div>
  );
};
