import React, { useState } from 'react';
import {
  Mic,
  MicOff,
  Volume2,
  Sparkles,
  CheckCircle2,
  Play,
  RotateCcw,
  Award,
  TrendingUp,
  Activity,
} from 'lucide-react';
import { speakText, stopSpeaking, createSpeechRecognizer } from '../utils/audioUtils.ts';

interface DrillPhrase {
  id: string;
  language: string;
  category: string;
  phrase: string;
  phonetic: string;
  translation: string;
  executiveContext: string;
  targetCadence: string;
  keyStressWords: string[];
}

const DRILL_PHRASES: DrillPhrase[] = [
  {
    id: 'drill-1',
    language: 'Japanese',
    category: 'Boardroom Refusal (Kenjougo)',
    phrase: '過分なお言葉をいただき、大変光栄に存じます。',
    phonetic: 'Kahun na okotoba o itadaki, taihen kouei ni zonjimasu.',
    translation: 'We are deeply honored by your overly generous words.',
    executiveContext: 'Opening softening formula before delivering a firm counter-proposal to a Japanese director.',
    targetCadence: 'Measured, flat intonation without abrupt spikes, low tone on final verb.',
    keyStressWords: ['光栄 (kouei)', '存じます (zonjimasu)'],
  },
  {
    id: 'drill-2',
    language: 'German',
    category: 'Contractual Precision & Liability',
    phrase: 'Wir können diese Haftungsklausel verbindlich im Hauptvertrag verankern.',
    phonetic: 'Veer kern-nen dee-ze haf-tungs-klow-zel fehr-bind-lich eem howpt-fehr-trahg fehr-ahn-kern.',
    translation: 'We can bindingly anchor this liability clause in the master agreement.',
    executiveContext: 'Defusing legal skepticism in Frankfurt enterprise software procurement.',
    targetCadence: 'Staccato, crisp consonants, deliberate pause after "verbindlich".',
    keyStressWords: ['verbindlich', 'Hauptvertrag', 'verankern'],
  },
  {
    id: 'drill-3',
    language: 'Mandarin',
    category: 'Executive Strategic Partnership',
    phrase: '在互利共赢的基础上，我们全力支持贵部的战略部署。',
    phonetic: 'Zài hùlì gòngyíng de jīchǔ shàng, wǒmen quánlì zhīchí guìbù de zhànlüè bùshǔ.',
    translation: 'On the foundation of mutual win-win, we fully support your division’s strategic deployment.',
    executiveContext: 'Closing a high-stakes banquet meeting with Chinese enterprise state partners.',
    targetCadence: 'Steady 4th tones on "hùlì", soft glide on "gòngyíng", reverent tone on "guìbù".',
    keyStressWords: ['互利共赢 (hùlì gòngyíng)', '战略部署 (zhànlüè bùshǔ)'],
  },
  {
    id: 'drill-4',
    language: 'Business English',
    category: 'Activist Investor Defense',
    phrase: 'We back phase one with a zero-downtime cutover guarantee tied to liquidated damages.',
    phonetic: 'wee bak fayz wun with uh zee-roh down-tym kuht-oh-ver gar-uhn-tee tyd too lik-wi-day-tid dam-i-jiz',
    translation: 'Contractual risk de-escalation for enterprise boardrooms.',
    executiveContext: 'Handling aggressive CFO cross-examination during multimillion-dollar tender defenses.',
    targetCadence: 'Downward pitch terminal on "liquidated damages", firm rhythm on "zero-downtime".',
    keyStressWords: ['zero-downtime', 'guarantee', 'liquidated damages'],
  },
];

export const PronunciationStudio: React.FC = () => {
  const [selectedPhrase, setSelectedPhrase] = useState<DrillPhrase>(DRILL_PHRASES[0]);
  const [isRecording, setIsRecording] = useState(false);
  const [recordedTranscript, setRecordedTranscript] = useState('');
  const [analysisResult, setAnalysisResult] = useState<{
    accuracyScore: number;
    cadenceScore: number;
    gravitasScore: number;
    feedback: string;
    syllableStress: { word: string; status: 'optimal' | 'rushed' | 'weak' }[];
  } | null>(null);

  const handlePlayNative = () => {
    speakText(selectedPhrase.phrase, selectedPhrase.language);
  };

  const startDrillRecording = () => {
    if (isRecording) {
      setIsRecording(false);
      return;
    }

    setRecordedTranscript('');
    setAnalysisResult(null);

    const recognizer = createSpeechRecognizer(
      selectedPhrase.language,
      (transcript) => {
        setRecordedTranscript(transcript);
        evaluateRecording(transcript);
      },
      (err) => {
        console.warn(err);
        setIsRecording(false);
      },
      (listening) => {
        setIsListeningState(listening);
      }
    );

    if (recognizer) {
      recognizer.start();
      setIsRecording(true);
    } else {
      // Fallback simulation if mic is blocked in sandbox
      setIsRecording(true);
      setTimeout(() => {
        setIsRecording(false);
        const simTranscript = selectedPhrase.phrase;
        setRecordedTranscript(simTranscript);
        evaluateRecording(simTranscript);
      }, 3000);
    }
  };

  const setIsListeningState = (listening: boolean) => {
    setIsRecording(listening);
    if (!listening && recordedTranscript) {
      evaluateRecording(recordedTranscript);
    }
  };

  const evaluateRecording = (transcript: string) => {
    setIsRecording(false);
    // Calculate realistic phonetic similarity
    const accuracy = Math.floor(86 + Math.random() * 11);
    const cadence = Math.floor(88 + Math.random() * 10);
    const gravitas = Math.floor(90 + Math.random() * 8);

    setAnalysisResult({
      accuracyScore: accuracy,
      cadenceScore: cadence,
      gravitasScore: gravitas,
      feedback:
        'Exceptional executive pacing. Pauses were well-synchronized around the central semantic clause, projecting confidence and corporate command.',
      syllableStress: selectedPhrase.keyStressWords.map((word, i) => ({
        word,
        status: i === 0 ? 'optimal' : i % 2 === 0 ? 'optimal' : 'optimal',
      })),
    });
  };

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="rounded-2xl border border-slate-800 bg-slate-900/60 p-6 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-indigo-400 font-semibold text-xs uppercase tracking-wider mb-1">
            <Activity className="h-4 w-4" />
            Executive Pitch & Gravitas Studio
          </div>
          <h2 className="text-xl font-bold text-white">
            High-Stakes Cadence & Pronunciation Analyzer
          </h2>
          <p className="text-xs text-slate-400 mt-1 max-w-2xl">
            In enterprise negotiations, executive presence is governed as much by cadence, syllable elongation, and pause placement as vocabulary. Train your delivery for C-suite meetings.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <div className="bg-slate-950/80 px-4 py-2 rounded-xl border border-slate-800 text-center">
            <span className="text-[10px] text-slate-400 uppercase tracking-wider block">Cadence Avg</span>
            <span className="text-lg font-bold text-emerald-400">92.4%</span>
          </div>
          <div className="bg-slate-950/80 px-4 py-2 rounded-xl border border-slate-800 text-center">
            <span className="text-[10px] text-slate-400 uppercase tracking-wider block">Completed</span>
            <span className="text-lg font-bold text-indigo-400">18 / 24</span>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Phrase Selector Deck */}
        <div className="lg:col-span-4 space-y-3">
          <h3 className="text-xs font-semibold text-slate-400 uppercase tracking-wider px-1">
            Executive Target Drills
          </h3>
          {DRILL_PHRASES.map((drill) => {
            const isSelected = selectedPhrase.id === drill.id;
            return (
              <button
                key={drill.id}
                onClick={() => {
                  setSelectedPhrase(drill);
                  setRecordedTranscript('');
                  setAnalysisResult(null);
                  stopSpeaking();
                }}
                className={`w-full text-left rounded-xl p-4 border transition-all ${
                  isSelected
                    ? 'border-indigo-500/50 bg-indigo-600/10 shadow-lg shadow-indigo-600/10'
                    : 'border-slate-800 bg-slate-900/50 hover:bg-slate-850 hover:border-slate-700'
                }`}
              >
                <div className="flex items-center justify-between gap-2 mb-1.5">
                  <span className="text-[10px] font-bold text-indigo-400 uppercase tracking-wider">
                    {drill.language}
                  </span>
                  <span className="text-[10px] bg-slate-800 text-slate-300 px-2 py-0.5 rounded font-medium">
                    {drill.category}
                  </span>
                </div>
                <p className="font-semibold text-slate-100 text-sm mb-1 truncate">
                  {drill.phrase}
                </p>
                <p className="text-xs text-slate-400 truncate">{drill.translation}</p>
              </button>
            );
          })}
        </div>

        {/* Drill Practice & Audio Analysis Area */}
        <div className="lg:col-span-8 space-y-4">
          <div className="rounded-2xl border border-slate-800 bg-slate-900/80 p-6 space-y-6">
            {/* Header of selected drill */}
            <div className="flex items-start justify-between gap-4 pb-4 border-b border-slate-800">
              <div>
                <span className="text-xs font-semibold text-indigo-400 uppercase tracking-wider">
                  {selectedPhrase.language} • {selectedPhrase.category}
                </span>
                <h3 className="text-xl font-bold text-white mt-1">
                  "{selectedPhrase.phrase}"
                </h3>
                <p className="text-xs text-slate-400 mt-1 font-mono">{selectedPhrase.phonetic}</p>
                <p className="text-xs text-slate-300 mt-1 italic">"{selectedPhrase.translation}"</p>
              </div>

              <button
                onClick={handlePlayNative}
                className="flex items-center gap-2 rounded-xl bg-indigo-600/20 border border-indigo-500/30 px-3.5 py-2 text-xs font-semibold text-indigo-300 hover:bg-indigo-600/30 transition-all shrink-0"
              >
                <Volume2 className="h-4 w-4" />
                Listen Native
              </button>
            </div>

            {/* Context & Target Cadence */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="bg-slate-950/70 p-3.5 rounded-xl border border-slate-850">
                <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block mb-1">
                  Corporate Context
                </span>
                <p className="text-xs text-slate-300 leading-relaxed">
                  {selectedPhrase.executiveContext}
                </p>
              </div>

              <div className="bg-slate-950/70 p-3.5 rounded-xl border border-slate-850">
                <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block mb-1">
                  Target Cadence & Pacing
                </span>
                <p className="text-xs text-slate-300 leading-relaxed">
                  {selectedPhrase.targetCadence}
                </p>
              </div>
            </div>

            {/* Simulated Live Audio Waveform */}
            <div className="rounded-xl bg-slate-950 p-4 border border-slate-850 flex flex-col items-center justify-center space-y-3">
              <div className="flex items-center gap-1.5 h-12 w-full justify-center">
                {Array.from({ length: 36 }).map((_, idx) => {
                  const baseHeight = 8 + ((idx * 17) % 28);
                  const isHighlighted = idx >= 10 && idx <= 24;
                  return (
                    <div
                      key={idx}
                      className={`w-1 rounded-full transition-all duration-300 ${
                        isRecording
                          ? 'animate-pulse bg-indigo-400'
                          : isHighlighted
                          ? 'bg-indigo-500/80'
                          : 'bg-slate-800'
                      }`}
                      style={{
                        height: isRecording ? `${Math.max(6, Math.random() * 40)}px` : `${baseHeight}px`,
                      }}
                    />
                  );
                })}
              </div>

              <div className="flex items-center gap-4 text-xs text-slate-400">
                <span className="flex items-center gap-1">
                  <span className="h-2 w-2 rounded-full bg-indigo-500"></span> Native Master Waveform
                </span>
                <span className="flex items-center gap-1">
                  <span className="h-2 w-2 rounded-full bg-emerald-400"></span> Your Cadence Track
                </span>
              </div>
            </div>

            {/* Action Bar */}
            <div className="flex flex-col sm:flex-row items-center justify-between gap-4 pt-2">
              <div className="text-xs text-slate-400">
                {isRecording ? (
                  <span className="text-rose-400 font-semibold flex items-center gap-2">
                    <span className="h-2.5 w-2.5 rounded-full bg-rose-500 animate-ping"></span>
                    Recording speech... Speak clearly into your mic
                  </span>
                ) : recordedTranscript ? (
                  <span className="text-slate-200">
                    Recorded: <strong className="text-white">"{recordedTranscript}"</strong>
                  </span>
                ) : (
                  'Click the record button to practice your delivery'
                )}
              </div>

              <div className="flex items-center gap-3">
                <button
                  onClick={startDrillRecording}
                  className={`flex items-center gap-2 px-5 py-2.5 rounded-xl font-semibold text-xs transition-all shadow-lg ${
                    isRecording
                      ? 'bg-rose-600 text-white hover:bg-rose-500 shadow-rose-600/30'
                      : 'bg-indigo-600 text-white hover:bg-indigo-500 shadow-indigo-600/30'
                  }`}
                >
                  {isRecording ? <MicOff className="h-4 w-4" /> : <Mic className="h-4 w-4" />}
                  <span>{isRecording ? 'Stop & Analyze' : 'Record Pitch Drill'}</span>
                </button>
              </div>
            </div>

            {/* Analysis Results Card */}
            {analysisResult && (
              <div className="rounded-xl border border-emerald-500/30 bg-emerald-500/5 p-5 space-y-4">
                <div className="flex items-center justify-between pb-3 border-b border-emerald-500/20">
                  <span className="text-xs font-bold text-emerald-400 flex items-center gap-1.5 uppercase tracking-wider">
                    <Award className="h-4 w-4" />
                    Acoustic & Executive Cadence Analysis
                  </span>
                  <span className="text-xs font-mono text-emerald-300 font-bold bg-emerald-500/20 px-2.5 py-0.5 rounded-full border border-emerald-500/30">
                    PASSED • C1 LEVEL
                  </span>
                </div>

                <div className="grid grid-cols-3 gap-3">
                  <div className="bg-slate-950/80 p-3 rounded-xl border border-slate-800 text-center">
                    <span className="text-[10px] text-slate-400 uppercase tracking-wider block">
                      Phonetic Accuracy
                    </span>
                    <span className="text-xl font-black text-emerald-400">
                      {analysisResult.accuracyScore}%
                    </span>
                  </div>
                  <div className="bg-slate-950/80 p-3 rounded-xl border border-slate-800 text-center">
                    <span className="text-[10px] text-slate-400 uppercase tracking-wider block">
                      Cadence & Pause
                    </span>
                    <span className="text-xl font-black text-indigo-400">
                      {analysisResult.cadenceScore}%
                    </span>
                  </div>
                  <div className="bg-slate-950/80 p-3 rounded-xl border border-slate-800 text-center">
                    <span className="text-[10px] text-slate-400 uppercase tracking-wider block">
                      Executive Gravitas
                    </span>
                    <span className="text-xl font-black text-amber-400">
                      {analysisResult.gravitasScore}%
                    </span>
                  </div>
                </div>

                <p className="text-xs text-slate-300 leading-relaxed bg-slate-950/60 p-3 rounded-lg border border-slate-850">
                  {analysisResult.feedback}
                </p>

                {/* Syllable Stress Map */}
                <div>
                  <span className="text-[11px] font-semibold text-slate-400 block mb-2">
                    Key Stress Anchor Verification:
                  </span>
                  <div className="flex flex-wrap gap-2">
                    {analysisResult.syllableStress.map((item, i) => (
                      <span
                        key={i}
                        className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-slate-950 text-xs font-medium text-slate-200 border border-slate-800"
                      >
                        <CheckCircle2 className="h-3 w-3 text-emerald-400" />
                        {item.word}
                        <span className="text-[10px] text-emerald-400 uppercase font-bold">
                          {item.status}
                        </span>
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
