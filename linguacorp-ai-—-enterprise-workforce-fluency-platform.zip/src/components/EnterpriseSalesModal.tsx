import React, { useState } from 'react';
import {
  X,
  Globe,
  CheckCircle2,
  ShieldCheck,
  Building2,
  Lock,
  Download,
  Mail,
  ArrowRight,
  Sparkles,
} from 'lucide-react';

interface EnterpriseSalesModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const EnterpriseSalesModal: React.FC<EnterpriseSalesModalProps> = ({
  isOpen,
  onClose,
}) => {
  const [selectedTier, setSelectedTier] = useState<'tier-global' | 'tier-conglomerate' | 'tier-sovereign'>('tier-global');
  const [seats, setSeats] = useState(1500);
  const [companyName, setCompanyName] = useState('');
  const [workEmail, setWorkEmail] = useState('');
  const [submitted, setSubmitted] = useState(false);

  if (!isOpen) return null;

  const pricePerSeatAnnual = selectedTier === 'tier-global' ? 948 : 840;
  const estimatedACV = Math.round(seats * pricePerSeatAnnual);
  const estimatedRevenueLift = Math.round(estimatedACV * 8.4);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="relative w-full max-w-2xl rounded-2xl border border-indigo-500/30 bg-slate-900 p-6 sm:p-8 shadow-2xl space-y-6 max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-800">
          <div className="flex items-center gap-3">
            <div className="h-10 w-10 rounded-xl bg-gradient-to-tr from-indigo-500 to-indigo-700 flex items-center justify-center text-white font-bold text-lg shadow-md shadow-indigo-600/30">
              LQ
            </div>
            <div>
              <h3 className="font-bold text-white text-lg">
                LinguaCorp AI Enterprise Procurement & RFP
              </h3>
              <p className="text-xs text-slate-400">
                Workforce Fluency Infrastructure for Fortune 500 & Global Enterprises
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-200 rounded-lg transition-colors"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {submitted ? (
          <div className="text-center py-8 space-y-4">
            <div className="h-16 w-16 rounded-full bg-emerald-500/20 border border-emerald-500/40 text-emerald-400 flex items-center justify-center mx-auto">
              <CheckCircle2 className="h-8 w-8" />
            </div>
            <h4 className="text-xl font-bold text-white">
              Enterprise RFP & Sandbox Request Received
            </h4>
            <p className="text-xs text-slate-300 max-w-md mx-auto leading-relaxed">
              Our Global Solutions Engineering lead has been assigned to <strong className="text-white">{companyName || 'your enterprise'}</strong>. A dedicated sovereign sandbox instance and SOC2 Type II audit packet have been dispatched to <strong className="text-indigo-300">{workEmail || 'your email'}</strong>.
            </p>
            <div className="pt-4 flex items-center justify-center gap-3">
              <button
                onClick={onClose}
                className="px-6 py-2 rounded-xl bg-indigo-600 text-white font-semibold text-xs hover:bg-indigo-500 transition-colors"
              >
                Return to Platform
              </button>
            </div>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-6 text-xs">
            {/* Tier Selector */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <button
                type="button"
                onClick={() => setSelectedTier('tier-global')}
                className={`text-left p-3.5 rounded-xl border transition-all ${
                  selectedTier === 'tier-global'
                    ? 'border-indigo-500 bg-indigo-600/10 text-white shadow-md'
                    : 'border-slate-800 bg-slate-950/60 text-slate-400 hover:border-slate-700'
                }`}
              >
                <div className="text-[10px] font-bold uppercase tracking-wider text-indigo-400 mb-1">
                  Standard
                </div>
                <div className="font-bold text-white text-sm">Enterprise Global</div>
                <p className="text-[11px] text-slate-400 mt-1">500 – 2,500 seats</p>
                <p className="text-[10px] text-emerald-400 font-semibold mt-2">$79 / seat / mo</p>
              </button>

              <button
                type="button"
                onClick={() => setSelectedTier('tier-conglomerate')}
                className={`text-left p-3.5 rounded-xl border transition-all ${
                  selectedTier === 'tier-conglomerate'
                    ? 'border-indigo-500 bg-indigo-600/10 text-white shadow-md'
                    : 'border-slate-800 bg-slate-950/60 text-slate-400 hover:border-slate-700'
                }`}
              >
                <div className="text-[10px] font-bold uppercase tracking-wider text-indigo-400 mb-1">
                  High Volume
                </div>
                <div className="font-bold text-white text-sm">Conglomerate Scale</div>
                <p className="text-[11px] text-slate-400 mt-1">2,500 – 15,000+ seats</p>
                <p className="text-[10px] text-emerald-400 font-semibold mt-2">Volume Negotiated</p>
              </button>

              <button
                type="button"
                onClick={() => setSelectedTier('tier-sovereign')}
                className={`text-left p-3.5 rounded-xl border transition-all ${
                  selectedTier === 'tier-sovereign'
                    ? 'border-indigo-500 bg-indigo-600/10 text-white shadow-md'
                    : 'border-slate-800 bg-slate-950/60 text-slate-400 hover:border-slate-700'
                }`}
              >
                <div className="text-[10px] font-bold uppercase tracking-wider text-purple-400 mb-1">
                  Air-Gapped
                </div>
                <div className="font-bold text-white text-sm">Sovereign Enclave</div>
                <p className="text-[11px] text-slate-400 mt-1">Private VPC / FedRAMP</p>
                <p className="text-[10px] text-purple-300 font-semibold mt-2">Dedicated Model</p>
              </button>
            </div>

            {/* Live Pricing & Value Estimator */}
            <div className="rounded-xl bg-slate-950/80 border border-slate-800 p-4 space-y-3">
              <div className="flex justify-between items-center text-xs">
                <span className="text-slate-400 font-medium">Requested Seat Capacity:</span>
                <span className="font-bold text-white">{seats.toLocaleString()} seats</span>
              </div>
              <input
                type="range"
                min="500"
                max="8000"
                step="250"
                value={seats}
                onChange={(e) => setSeats(Number(e.target.value))}
                className="w-full accent-indigo-500 cursor-pointer"
              />

              <div className="grid grid-cols-2 gap-3 pt-2 border-t border-slate-850 text-xs">
                <div>
                  <span className="text-slate-500 block">Estimated Annual License:</span>
                  <span className="text-lg font-black text-white">
                    ${(estimatedACV / 1000).toLocaleString()}k / yr
                  </span>
                </div>
                <div>
                  <span className="text-slate-500 block">Projected Deal Velocity Lift:</span>
                  <span className="text-lg font-black text-emerald-400">
                    +${(estimatedRevenueLift / 1000000).toFixed(1)}M ARR
                  </span>
                </div>
              </div>
            </div>

            {/* Enterprise Lead Information */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="text-slate-300 font-semibold block mb-1">
                  Enterprise Company Name:
                </label>
                <input
                  type="text"
                  required
                  value={companyName}
                  onChange={(e) => setCompanyName(e.target.value)}
                  placeholder="e.g. Novartis Global, Siemens, Nomura"
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-100 focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div>
                <label className="text-slate-300 font-semibold block mb-1">
                  Corporate Work Email:
                </label>
                <input
                  type="email"
                  required
                  value={workEmail}
                  onChange={(e) => setWorkEmail(e.target.value)}
                  placeholder="executive@company.com"
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-100 focus:outline-none focus:border-indigo-500"
                />
              </div>
            </div>

            {/* Enterprise Security Badges Included */}
            <div className="pt-2 flex flex-wrap items-center gap-4 text-slate-400 text-[11px]">
              <span className="flex items-center gap-1.5 text-slate-300">
                <ShieldCheck className="h-4 w-4 text-emerald-400" /> SOC2 Type II Certified
              </span>
              <span className="flex items-center gap-1.5 text-slate-300">
                <Lock className="h-4 w-4 text-indigo-400" /> Okta SAML 2.0 SSO
              </span>
              <span className="flex items-center gap-1.5 text-slate-300">
                <Globe className="h-4 w-4 text-purple-400" /> EU Data Sovereignty Guaranteed
              </span>
            </div>

            {/* Actions */}
            <div className="pt-4 border-t border-slate-800 flex items-center justify-between">
              <button
                type="button"
                onClick={() => alert('Downloaded LinguaCorp_AI_Enterprise_Security_Whitepaper.pdf')}
                className="flex items-center gap-1.5 text-indigo-400 hover:text-indigo-300 font-medium"
              >
                <Download className="h-4 w-4" /> Download Security Whitepaper
              </button>

              <div className="flex items-center gap-3">
                <button
                  type="button"
                  onClick={onClose}
                  className="px-4 py-2 text-slate-400 hover:text-slate-200"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-gradient-to-r from-indigo-500 to-indigo-600 text-white font-semibold shadow-lg shadow-indigo-600/20 hover:from-indigo-600 hover:to-indigo-700 transition-all"
                >
                  <span>Submit RFP & Provision Sandbox</span>
                  <ArrowRight className="h-4 w-4" />
                </button>
              </div>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};
