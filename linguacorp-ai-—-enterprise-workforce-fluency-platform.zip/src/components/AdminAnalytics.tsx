import React, { useState } from 'react';
import {
  BarChart3,
  TrendingUp,
  Users,
  Globe2,
  DollarSign,
  Download,
  ShieldCheck,
  Building,
  CheckCircle2,
  ArrowUpRight,
  Calculator,
  Upload,
  Lock,
  FileSpreadsheet,
  Layers,
  Clock,
  Sparkles,
} from 'lucide-react';
import {
  COMPANY_PROFILE,
  REGIONAL_METRICS,
  DEPARTMENT_METRICS,
} from '../data/enterpriseData.ts';

export const AdminAnalytics: React.FC = () => {
  // ROI Calculator states
  const [repsCount, setRepsCount] = useState<number>(250);
  const [avgDealSize, setAvgDealSize] = useState<number>(650000); // $650k
  const [crossBorderPipeline, setCrossBorderPipeline] = useState<number>(85000000); // $85M

  // Calculated ROI values
  const winRateBoostPercent = 4.8; // +4.8% win rate increase
  const pipelineWonAddition = Math.round((crossBorderPipeline * winRateBoostPercent) / 100);
  const licenseCostEstimate = repsCount * 960; // $960 / user / year
  const calculatedROI = Math.round((pipelineWonAddition / licenseCostEstimate) * 10) / 10;
  const cycleReductionWeeks = 3.6;

  // Custom Lexicon file state
  const [uploadStatus, setUploadStatus] = useState<string | null>(null);

  const handleSimulateExport = () => {
    alert(
      'Exporting "OmniVanguard_Global_Fluency_Executive_Report_Q3_2026.csv" with full department telemetry, CEFR breakdowns, and SOC2 audit log.'
    );
  };

  const handleSimulateUpload = () => {
    setUploadStatus('Analyzing corporate glossary...');
    setTimeout(() => {
      setUploadStatus('Successfully ingested 142 proprietary acronyms and contract clauses into Gemini AI Enterprise Tutor.');
    }, 1200);
  };

  return (
    <div className="space-y-8">
      {/* Top Banner & KPI Summary */}
      <div className="rounded-2xl border border-slate-800 bg-gradient-to-br from-slate-900 via-slate-900/90 to-slate-950 p-6 shadow-2xl">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 pb-6 border-b border-slate-800">
          <div>
            <div className="flex items-center gap-2 text-indigo-400 font-semibold text-xs uppercase tracking-wider mb-1">
              <BarChart3 className="h-4 w-4" />
              Workforce Language Intelligence & Fluency Analytics
            </div>
            <h2 className="text-2xl font-black text-white tracking-tight">
              {COMPANY_PROFILE.name}
            </h2>
            <p className="text-xs text-slate-400 mt-1">
              Global Enterprise Telemetry • 5 Regional Hubs • {COMPANY_PROFILE.activeSeats} Active Executives
            </p>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={handleSimulateExport}
              className="flex items-center gap-2 rounded-xl border border-slate-700 bg-slate-800 px-4 py-2 text-xs font-semibold text-slate-200 hover:bg-slate-750 transition-all shadow-md"
            >
              <Download className="h-4 w-4 text-slate-400" />
              <span>Export Board Deck (CSV/PDF)</span>
            </button>
          </div>
        </div>

        {/* 5 Core Enterprise KPIs */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-4 pt-6">
          <div className="bg-slate-950/70 p-4 rounded-xl border border-slate-850">
            <div className="flex items-center justify-between text-slate-400 text-xs mb-1">
              <span>Seat Allocation</span>
              <Users className="h-3.5 w-3.5 text-indigo-400" />
            </div>
            <div className="flex items-baseline gap-1">
              <span className="text-2xl font-black text-white">
                {COMPANY_PROFILE.activeSeats}
              </span>
              <span className="text-xs text-slate-500">/ {COMPANY_PROFILE.totalSeatsPurchased}</span>
            </div>
            <span className="text-[11px] font-semibold text-emerald-400 mt-1 block">
              {COMPANY_PROFILE.seatUtilizationRate}% Utilization
            </span>
          </div>

          <div className="bg-slate-950/70 p-4 rounded-xl border border-slate-850">
            <div className="flex items-center justify-between text-slate-400 text-xs mb-1">
              <span>Enterprise Fluency</span>
              <TrendingUp className="h-3.5 w-3.5 text-emerald-400" />
            </div>
            <div className="flex items-baseline gap-1">
              <span className="text-2xl font-black text-emerald-400">
                {COMPANY_PROFILE.overallFluencyScore}
              </span>
              <span className="text-xs text-slate-500">/ 100</span>
            </div>
            <span className="text-[11px] font-semibold text-indigo-300 mt-1 block">
              Median CEFR: {COMPANY_PROFILE.cefrMedian}
            </span>
          </div>

          <div className="bg-slate-950/70 p-4 rounded-xl border border-slate-850">
            <div className="flex items-center justify-between text-slate-400 text-xs mb-1">
              <span>Deal Velocity Impact</span>
              <ArrowUpRight className="h-3.5 w-3.5 text-indigo-400" />
            </div>
            <div className="text-2xl font-black text-indigo-400">
              {COMPANY_PROFILE.dealVelocityIncrease}
            </div>
            <span className="text-[11px] font-semibold text-slate-400 mt-1 block">
              Faster Contract Closes
            </span>
          </div>

          <div className="bg-slate-950/70 p-4 rounded-xl border border-slate-850">
            <div className="flex items-center justify-between text-slate-400 text-xs mb-1">
              <span>Slippage Mitigated</span>
              <DollarSign className="h-3.5 w-3.5 text-emerald-400" />
            </div>
            <div className="text-2xl font-black text-emerald-400">
              {COMPANY_PROFILE.lostDealsMitigatedEst}
            </div>
            <span className="text-[11px] font-semibold text-slate-400 mt-1 block">
              Cross-border pipeline saved
            </span>
          </div>

          <div className="bg-slate-950/70 p-4 rounded-xl border border-slate-850 col-span-2 sm:col-span-1">
            <div className="flex items-center justify-between text-slate-400 text-xs mb-1">
              <span>Simulation Hours</span>
              <Clock className="h-3.5 w-3.5 text-purple-400" />
            </div>
            <div className="text-2xl font-black text-white">
              {COMPANY_PROFILE.totalHoursTrained.toLocaleString()}
            </div>
            <span className="text-[11px] font-semibold text-emerald-400 mt-1 block">
              {COMPANY_PROFILE.monthlySimulationsCompleted.toLocaleString()} sessions MoM
            </span>
          </div>
        </div>
      </div>

      {/* Regional Fluency & Hubs Benchmark */}
      <div className="rounded-2xl border border-slate-800 bg-slate-900/70 p-6 shadow-xl space-y-5">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Globe2 className="h-5 w-5 text-indigo-400" />
            <div>
              <h3 className="font-bold text-white text-base">Regional Hub Benchmark & Enrollment</h3>
              <p className="text-xs text-slate-400">Tracking multinational team language readiness by operational geography</p>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
          {REGIONAL_METRICS.map((hub) => (
            <div
              key={hub.city}
              className="rounded-xl border border-slate-800 bg-slate-950/70 p-4 hover:border-indigo-500/40 transition-all flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center justify-between text-xs mb-2">
                  <span className="text-xl">{hub.flag}</span>
                  <span className="text-[10px] font-semibold text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded">
                    {hub.changeRate}
                  </span>
                </div>
                <h4 className="font-bold text-white text-sm">{hub.city}</h4>
                <p className="text-[11px] text-slate-400 mt-0.5">{hub.region}</p>
                <div className="mt-3">
                  <span className="text-[10px] text-slate-500 uppercase tracking-wider block">Fluency Avg</span>
                  <span className="text-xl font-black text-emerald-400">{hub.fluencyAverage}%</span>
                </div>
              </div>

              <div className="mt-3 pt-3 border-t border-slate-850 text-[11px]">
                <span className="text-slate-400 block font-medium">Primary Track:</span>
                <span className="text-slate-200 truncate block mt-0.5">{hub.primaryTrack}</span>
                <span className="text-slate-500 text-[10px] mt-1 block">{hub.seats} active seats</span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Department Fluency & Competency Heatmap Matrix */}
      <div className="rounded-2xl border border-slate-800 bg-slate-900/70 p-6 shadow-xl space-y-5">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Layers className="h-5 w-5 text-indigo-400" />
            <div>
              <h3 className="font-bold text-white text-base">Departmental Competency Matrix</h3>
              <p className="text-xs text-slate-400">Granular breakdown across negotiation, executive presentation, and technical debate</p>
            </div>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400 uppercase tracking-wider text-[10px]">
                <th className="py-3 px-4">Department</th>
                <th className="py-3 px-4">Seats</th>
                <th className="py-3 px-4">Active Rate</th>
                <th className="py-3 px-4">CEFR Median</th>
                <th className="py-3 px-4">Negotiation (0-100)</th>
                <th className="py-3 px-4">Presentation (0-100)</th>
                <th className="py-3 px-4">Technical Precision</th>
                <th className="py-3 px-4">Commercial Impact</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {DEPARTMENT_METRICS.map((dept) => (
                <tr key={dept.department} className="hover:bg-slate-800/40 transition-colors">
                  <td className="py-3.5 px-4 font-semibold text-white">
                    {dept.department}
                  </td>
                  <td className="py-3.5 px-4 text-slate-300">{dept.headCount}</td>
                  <td className="py-3.5 px-4">
                    <span className="text-emerald-400 font-semibold">{dept.activeRate}%</span>
                  </td>
                  <td className="py-3.5 px-4">
                    <span className="bg-indigo-500/20 text-indigo-300 px-2 py-0.5 rounded font-bold border border-indigo-500/30">
                      {dept.cefrMedian}
                    </span>
                  </td>
                  <td className="py-3.5 px-4">
                    <div className="flex items-center gap-2">
                      <span className="w-7 font-bold text-slate-200">{dept.negotiationMastery}%</span>
                      <div className="w-20 bg-slate-800 h-1.5 rounded-full overflow-hidden">
                        <div
                          className="h-full bg-indigo-500 rounded-full"
                          style={{ width: `${dept.negotiationMastery}%` }}
                        />
                      </div>
                    </div>
                  </td>
                  <td className="py-3.5 px-4">
                    <div className="flex items-center gap-2">
                      <span className="w-7 font-bold text-slate-200">{dept.presentationMastery}%</span>
                      <div className="w-20 bg-slate-800 h-1.5 rounded-full overflow-hidden">
                        <div
                          className="h-full bg-emerald-400 rounded-full"
                          style={{ width: `${dept.presentationMastery}%` }}
                        />
                      </div>
                    </div>
                  </td>
                  <td className="py-3.5 px-4">
                    <div className="flex items-center gap-2">
                      <span className="w-7 font-bold text-slate-200">{dept.technicalPrecision}%</span>
                      <div className="w-20 bg-slate-800 h-1.5 rounded-full overflow-hidden">
                        <div
                          className="h-full bg-amber-400 rounded-full"
                          style={{ width: `${dept.technicalPrecision}%` }}
                        />
                      </div>
                    </div>
                  </td>
                  <td className="py-3.5 px-4 text-slate-300 italic max-w-xs truncate">
                    {dept.dealVelocityImpact}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Interactive Enterprise ROI & Business Impact Calculator */}
      <div className="rounded-2xl border border-indigo-500/30 bg-gradient-to-br from-slate-900 via-slate-900 to-indigo-950/40 p-6 shadow-2xl space-y-6">
        <div className="flex items-center justify-between pb-4 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <Calculator className="h-5 w-5 text-indigo-400" />
            <div>
              <h3 className="font-bold text-white text-base">Enterprise ROI & Win-Rate Simulator</h3>
              <p className="text-xs text-slate-400">Model revenue acceleration and churn mitigation from workforce language mastery</p>
            </div>
          </div>
          <span className="text-xs font-semibold text-emerald-400 bg-emerald-500/10 border border-emerald-500/20 px-3 py-1 rounded-full">
            Dynamic Financial Projection
          </span>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
          {/* Sliders Input */}
          <div className="lg:col-span-7 space-y-5">
            <div>
              <div className="flex justify-between text-xs text-slate-300 font-medium mb-1.5">
                <span>Number of Global Enterprise Reps / Negotiators:</span>
                <span className="font-bold text-white">{repsCount} reps</span>
              </div>
              <input
                type="range"
                min="25"
                max="1000"
                step="25"
                value={repsCount}
                onChange={(e) => setRepsCount(Number(e.target.value))}
                className="w-full accent-indigo-500 cursor-pointer"
              />
            </div>

            <div>
              <div className="flex justify-between text-xs text-slate-300 font-medium mb-1.5">
                <span>Average Cross-Border Deal Size:</span>
                <span className="font-bold text-white">${(avgDealSize / 1000).toLocaleString()}k</span>
              </div>
              <input
                type="range"
                min="100000"
                max="3000000"
                step="50000"
                value={avgDealSize}
                onChange={(e) => setAvgDealSize(Number(e.target.value))}
                className="w-full accent-indigo-500 cursor-pointer"
              />
            </div>

            <div>
              <div className="flex justify-between text-xs text-slate-300 font-medium mb-1.5">
                <span>Annual Cross-Border Pipeline Monitored:</span>
                <span className="font-bold text-white">${(crossBorderPipeline / 1000000).toFixed(1)}M</span>
              </div>
              <input
                type="range"
                min="10000000"
                max="250000000"
                step="5000000"
                value={crossBorderPipeline}
                onChange={(e) => setCrossBorderPipeline(Number(e.target.value))}
                className="w-full accent-indigo-500 cursor-pointer"
              />
            </div>
          </div>

          {/* Projection Outputs */}
          <div className="lg:col-span-5 rounded-xl bg-slate-950/80 border border-slate-800 p-5 space-y-4">
            <div className="border-b border-slate-850 pb-3">
              <span className="text-[10px] text-slate-400 uppercase tracking-wider font-semibold block">
                Projected Incremental ARR
              </span>
              <div className="text-3xl font-black text-emerald-400 mt-0.5">
                +${(pipelineWonAddition / 1000000).toFixed(2)}M
              </div>
              <span className="text-[11px] text-slate-400 mt-1 block">
                Based on +{winRateBoostPercent}% lift in foreign tender win rates
              </span>
            </div>

            <div className="grid grid-cols-2 gap-3 text-xs">
              <div>
                <span className="text-slate-500 block">Deal Cycle Acceleration:</span>
                <span className="font-bold text-indigo-300 text-sm">-{cycleReductionWeeks} weeks</span>
              </div>
              <div>
                <span className="text-slate-500 block">Estimated ROI:</span>
                <span className="font-bold text-emerald-400 text-sm">{calculatedROI}x Multiplier</span>
              </div>
            </div>

            <p className="text-[11px] text-slate-400 italic border-t border-slate-850 pt-2 leading-relaxed">
              *Calculated against LinguaCorp AI platform license costs of ${(licenseCostEstimate / 1000).toFixed(1)}k/yr for {repsCount} enterprise seats.
            </p>
          </div>
        </div>
      </div>

      {/* Enterprise Security, Ingestion & Lexicon Customizer */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Custom Lexicon Ingestion Card */}
        <div className="rounded-2xl border border-slate-800 bg-slate-900/70 p-6 shadow-xl space-y-4">
          <div className="flex items-center gap-2">
            <Upload className="h-5 w-5 text-indigo-400" />
            <div>
              <h3 className="font-bold text-white text-base">Proprietary Corporate Glossary Ingestion</h3>
              <p className="text-xs text-slate-400">Inject custom enterprise acronyms, trademarked products, and contract clauses into Gemini AI</p>
            </div>
          </div>

          <p className="text-xs text-slate-300 leading-relaxed">
            Upload internal product taxonomies, compliance manuals, or deal term templates. The Gemini AI tutor will automatically weave your proprietary terminology into executive simulation dialogues.
          </p>

          <div className="border-2 border-dashed border-slate-700 hover:border-indigo-500/50 rounded-xl p-6 text-center cursor-pointer bg-slate-950/60 transition-colors">
            <FileSpreadsheet className="h-8 w-8 text-indigo-400 mx-auto mb-2" />
            <span className="text-xs font-semibold text-slate-200 block">
              Drag & Drop Corporate Glossary (.CSV, .JSON, .DOCX)
            </span>
            <span className="text-[10px] text-slate-500 mt-1 block">
              Max file size 25MB • AES-256 Encrypted on upload
            </span>
            <button
              type="button"
              onClick={handleSimulateUpload}
              className="mt-3 px-4 py-1.5 rounded-lg bg-indigo-600/20 border border-indigo-500/40 text-xs font-semibold text-indigo-300 hover:bg-indigo-600/30 transition-all"
            >
              Upload Sample Enterprise Lexicon
            </button>
          </div>

          {uploadStatus && (
            <div className="p-3 rounded-lg bg-emerald-500/10 border border-emerald-500/30 text-xs text-emerald-300 flex items-center gap-2">
              <CheckCircle2 className="h-4 w-4 shrink-0 text-emerald-400" />
              <span>{uploadStatus}</span>
            </div>
          )}
        </div>

        {/* Security & Multi-Tenant Compliance */}
        <div className="rounded-2xl border border-slate-800 bg-slate-900/70 p-6 shadow-xl space-y-4">
          <div className="flex items-center gap-2">
            <ShieldCheck className="h-5 w-5 text-emerald-400" />
            <div>
              <h3 className="font-bold text-white text-base">Enterprise Compliance & Security Enclave</h3>
              <p className="text-xs text-slate-400">Dedicated sovereign tenant configuration and audit logs</p>
            </div>
          </div>

          <div className="space-y-2.5 text-xs">
            <div className="flex items-center justify-between p-3 rounded-xl bg-slate-950/70 border border-slate-850">
              <div className="flex items-center gap-2.5">
                <Lock className="h-4 w-4 text-emerald-400" />
                <div>
                  <span className="font-semibold text-slate-200 block">Okta & Azure AD SAML 2.0</span>
                  <span className="text-[10px] text-slate-500">Automated employee provisioning & SCIM</span>
                </div>
              </div>
              <span className="text-emerald-400 font-bold text-[11px] bg-emerald-500/10 px-2 py-0.5 rounded">
                CONNECTED
              </span>
            </div>

            <div className="flex items-center justify-between p-3 rounded-xl bg-slate-950/70 border border-slate-850">
              <div className="flex items-center gap-2.5">
                <Globe2 className="h-4 w-4 text-indigo-400" />
                <div>
                  <span className="font-semibold text-slate-200 block">EU GDPR & BaFin Data Residency</span>
                  <span className="text-[10px] text-slate-500">Primary storage: Frankfurt (fra1-core-01)</span>
                </div>
              </div>
              <span className="text-indigo-300 font-bold text-[11px] bg-indigo-500/10 px-2 py-0.5 rounded">
                ENFORCED
              </span>
            </div>

            <div className="flex items-center justify-between p-3 rounded-xl bg-slate-950/70 border border-slate-850">
              <div className="flex items-center gap-2.5">
                <Sparkles className="h-4 w-4 text-purple-400" />
                <div>
                  <span className="font-semibold text-slate-200 block">Zero-Retention AI Training Guarantee</span>
                  <span className="text-[10px] text-slate-500">Learner audio and transcripts are never retained for model training</span>
                </div>
              </div>
              <span className="text-purple-300 font-bold text-[11px] bg-purple-500/10 px-2 py-0.5 rounded">
                STRICT POLICY
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
