import React, { useState } from 'react';
import {
  Award,
  CheckCircle2,
  ShieldCheck,
  FileCheck,
  ExternalLink,
  Download,
  Calendar,
  Lock,
  ChevronRight,
  Sparkles,
} from 'lucide-react';
import { SAMPLE_LEARNER } from '../data/enterpriseData.ts';

export const CertificationView: React.FC = () => {
  const [examActive, setExamActive] = useState(false);
  const [examCompleted, setExamCompleted] = useState(false);
  const [examScore, setExamScore] = useState(94);
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);

  const sampleQuestions = [
    {
      prompt: 'During an executive meeting in Tokyo, the client Managing Director states: "今回の条件につきましては、社内で持ち帰り慎重に検討させていただきます。" What is the most commercially accurate interpretation?',
      options: [
        'They are enthusiastic and will sign by the end of the business day.',
        'It is an indirect refusal or polite signal that your proposal currently lacks consensus internal alignment.',
        'They are demanding you drop your price by 50% immediately.',
        'They are asking for a public media briefing.',
      ],
      correctIndex: 1,
    },
    {
      prompt: 'Under German corporate law, when an enterprise client demands "eine verschuldensunabhängige Haftung", what are they requesting and how should enterprise counsel respond?',
      options: [
        'They want unlimited payment terms with zero interest.',
        'They are requesting strict liability regardless of fault; enterprise counsel must push back and cap liability at willful intent or gross negligence.',
        'They are asking for dual-datacenter hosting at no cost.',
        'They are waiving all contractual penalties.',
      ],
      correctIndex: 1,
    },
    {
      prompt: 'In Chinese cross-border business discussions, what is the strategic significance of signing an initial "谅解备忘录 (Memorandum of Understanding)" before legal contracts?',
      options: [
        'It is purely symbolic with zero business relevance.',
        'It creates a binding penal obligation under international maritime law.',
        'It formally establishes executive Guanxi and sets the political framework needed for internal government and board approvals.',
        'It guarantees 100% upfront wire transfer within 24 hours.',
      ],
      correctIndex: 2,
    },
  ];

  const handleNextQuestion = () => {
    if (currentQuestion < sampleQuestions.length - 1) {
      setCurrentQuestion(currentQuestion + 1);
      setSelectedAnswer(null);
    } else {
      setExamCompleted(true);
      setExamActive(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="rounded-2xl border border-slate-800 bg-slate-900/60 p-6 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-indigo-400 font-semibold text-xs uppercase tracking-wider mb-1">
            <Award className="h-4 w-4" />
            Enterprise Language Certification Standard
          </div>
          <h2 className="text-xl font-bold text-white">
            CEFR C1 / C2 Executive Business Fluency Credential
          </h2>
          <p className="text-xs text-slate-400 mt-1 max-w-2xl">
            Certified by LinguaCorp AI Enterprise Standards in compliance with Common European Framework of Reference (CEFR) for high-stakes corporate communication.
          </p>
        </div>

        {!examActive && !examCompleted && (
          <button
            onClick={() => {
              setExamActive(true);
              setCurrentQuestion(0);
              setSelectedAnswer(null);
            }}
            className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-gradient-to-r from-indigo-500 to-indigo-600 text-white font-semibold text-xs shadow-lg shadow-indigo-600/20 hover:from-indigo-600 hover:to-indigo-700 transition-all shrink-0"
          >
            <Sparkles className="h-4 w-4" />
            Take Recertification Assessment
          </button>
        )}
      </div>

      {examActive ? (
        /* Active Exam View */
        <div className="rounded-2xl border border-indigo-500/40 bg-slate-900/90 p-8 shadow-2xl max-w-3xl mx-auto space-y-6">
          <div className="flex items-center justify-between pb-4 border-b border-slate-800">
            <div>
              <span className="text-xs font-semibold text-indigo-400 uppercase tracking-wider">
                Question {currentQuestion + 1} of {sampleQuestions.length}
              </span>
              <h3 className="text-base font-bold text-white mt-1">
                Executive Situational Judgment Exam
              </h3>
            </div>
            <span className="text-xs font-mono text-slate-400 bg-slate-950 px-3 py-1 rounded-lg border border-slate-800">
              Time Remaining: 14:20
            </span>
          </div>

          <p className="text-sm font-medium text-slate-200 leading-relaxed bg-slate-950/70 p-4 rounded-xl border border-slate-850">
            {sampleQuestions[currentQuestion].prompt}
          </p>

          <div className="space-y-3">
            {sampleQuestions[currentQuestion].options.map((opt, idx) => (
              <button
                key={idx}
                onClick={() => setSelectedAnswer(idx)}
                className={`w-full text-left p-4 rounded-xl text-xs font-medium border transition-all ${
                  selectedAnswer === idx
                    ? 'border-indigo-500 bg-indigo-600/20 text-indigo-200 shadow-md'
                    : 'border-slate-800 bg-slate-950/60 text-slate-300 hover:border-slate-700 hover:bg-slate-850'
                }`}
              >
                <div className="flex items-center gap-3">
                  <span
                    className={`h-5 w-5 rounded-full flex items-center justify-center text-[10px] font-bold ${
                      selectedAnswer === idx ? 'bg-indigo-600 text-white' : 'bg-slate-800 text-slate-400'
                    }`}
                  >
                    {String.fromCharCode(65 + idx)}
                  </span>
                  <span>{opt}</span>
                </div>
              </button>
            ))}
          </div>

          <div className="flex items-center justify-between pt-4 border-t border-slate-800">
            <button
              onClick={() => setExamActive(false)}
              className="text-xs text-slate-400 hover:text-slate-200"
            >
              Exit Assessment
            </button>
            <button
              disabled={selectedAnswer === null}
              onClick={handleNextQuestion}
              className="flex items-center gap-2 px-5 py-2 rounded-xl bg-indigo-600 text-white text-xs font-semibold hover:bg-indigo-500 disabled:opacity-50 disabled:cursor-not-allowed transition-all"
            >
              <span>{currentQuestion === sampleQuestions.length - 1 ? 'Submit Exam' : 'Next Question'}</span>
              <ChevronRight className="h-4 w-4" />
            </button>
          </div>
        </div>
      ) : (
        /* Verified Digital Certificate Badge Display */
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          {/* Certificate Card */}
          <div className="lg:col-span-8 rounded-2xl border-2 border-indigo-500/30 bg-gradient-to-b from-slate-900 via-slate-900/95 to-slate-950 p-8 shadow-2xl relative overflow-hidden">
            {/* Watermark badge */}
            <div className="absolute right-6 top-6 opacity-10 pointer-events-none">
              <Award className="h-64 w-64 text-indigo-400" />
            </div>

            <div className="flex items-center justify-between pb-6 border-b border-slate-800 relative z-10">
              <div className="flex items-center gap-3">
                <div className="h-12 w-12 rounded-xl bg-gradient-to-tr from-indigo-500 to-indigo-700 flex items-center justify-center text-white font-black text-xl shadow-lg shadow-indigo-600/30">
                  LQ
                </div>
                <div>
                  <h4 className="font-bold text-white text-base">LINGUACORP AI ENTERPRISE</h4>
                  <p className="text-xs text-indigo-400">Global Corporate Workforce Fluency Council</p>
                </div>
              </div>
              <div className="flex items-center gap-1.5 text-xs text-emerald-400 bg-emerald-500/10 border border-emerald-500/30 px-3 py-1 rounded-full font-semibold">
                <ShieldCheck className="h-4 w-4" />
                VERIFIED CREDENTIAL
              </div>
            </div>

            <div className="my-8 text-center space-y-2 relative z-10">
              <p className="text-xs text-slate-400 uppercase tracking-widest font-semibold">
                This is officially certified that
              </p>
              <h2 className="text-3xl font-black text-white tracking-tight">
                {SAMPLE_LEARNER.name}
              </h2>
              <p className="text-xs text-indigo-300 font-medium">
                {SAMPLE_LEARNER.role} • {SAMPLE_LEARNER.department}
              </p>
              <p className="text-xs text-slate-400 max-w-xl mx-auto pt-2 leading-relaxed">
                has successfully defended high-stakes boardroom simulations, crisis incident handling, and contractual diplomacy, meeting the executive mastery threshold for:
              </p>
              <div className="inline-block mt-3 px-6 py-2 rounded-xl bg-indigo-500/20 border border-indigo-500/40 text-indigo-200 font-bold text-lg tracking-wide">
                CEFR C1 — Executive Business Japanese & Cross-Border Tech
              </div>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 pt-6 border-t border-slate-800 text-xs relative z-10">
              <div>
                <span className="text-slate-500 block">Assessment Score:</span>
                <span className="font-bold text-emerald-400 text-base">94.2 / 100</span>
              </div>
              <div>
                <span className="text-slate-500 block">Credential ID:</span>
                <span className="font-mono text-slate-200">LQ-2026-C1-8841</span>
              </div>
              <div>
                <span className="text-slate-500 block">Issue Date:</span>
                <span className="text-slate-200">Sept 18, 2026</span>
              </div>
              <div>
                <span className="text-slate-500 block">Validity:</span>
                <span className="text-slate-200">Permanent (Annual Audit)</span>
              </div>
            </div>

            {/* Cryptographic hash */}
            <div className="mt-6 pt-4 border-t border-slate-800/80 flex flex-col sm:flex-row items-center justify-between gap-3 text-[11px] text-slate-500 font-mono">
              <span className="truncate max-w-md">
                SHA-256: 8f9b4c71a3d2e0915fba41c3098e944201dfce21980a37b120
              </span>
              <div className="flex items-center gap-3">
                <button
                  onClick={() => alert('Certificate PDF generated and downloaded.')}
                  className="flex items-center gap-1 text-indigo-400 hover:text-indigo-300 font-sans font-medium"
                >
                  <Download className="h-3.5 w-3.5" /> Download PDF
                </button>
              </div>
            </div>
          </div>

          {/* Verification & Skill breakdown */}
          <div className="lg:col-span-4 space-y-4">
            <div className="rounded-2xl border border-slate-800 bg-slate-900/70 p-5 shadow-xl space-y-3">
              <h4 className="text-xs font-semibold text-slate-400 uppercase tracking-wider flex items-center gap-1.5">
                <CheckCircle2 className="h-4 w-4 text-emerald-400" />
                Verified Competency Profile
              </h4>

              <div className="space-y-2 text-xs">
                <div className="flex justify-between py-1 border-b border-slate-800">
                  <span className="text-slate-300">Kenjougo & Sonkeigo Verbs</span>
                  <span className="font-bold text-emerald-400">96%</span>
                </div>
                <div className="flex justify-between py-1 border-b border-slate-800">
                  <span className="text-slate-300">Contractual Liability Defense</span>
                  <span className="font-bold text-emerald-400">92%</span>
                </div>
                <div className="flex justify-between py-1 border-b border-slate-800">
                  <span className="text-slate-300">Indirect Refusal Pacing</span>
                  <span className="font-bold text-emerald-400">95%</span>
                </div>
                <div className="flex justify-between py-1 border-b border-slate-800">
                  <span className="text-slate-300">Cross-Cultural Face Preservation</span>
                  <span className="font-bold text-emerald-400">94%</span>
                </div>
              </div>
            </div>

            <div className="rounded-2xl border border-slate-800 bg-slate-900/70 p-5 shadow-xl space-y-3 text-xs">
              <span className="text-slate-400 font-semibold uppercase tracking-wider block">
                Enterprise L&D Verification
              </span>
              <p className="text-slate-300 leading-relaxed">
                This digital credential is automatically synchronized with your enterprise HRIS (Workday, SAP SuccessFactors, and Okta Profiles).
              </p>
              <div className="pt-2">
                <span className="inline-flex items-center gap-1.5 text-indigo-400 font-medium">
                  <ShieldCheck className="h-4 w-4" /> Workday Skill Cloud Synced
                </span>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
