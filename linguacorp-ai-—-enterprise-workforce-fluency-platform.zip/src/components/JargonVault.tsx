import React, { useState } from 'react';
import {
  BookOpen,
  Search,
  Filter,
  CheckCircle2,
  Volume2,
  Sparkles,
  Lightbulb,
  Building,
  GraduationCap,
} from 'lucide-react';
import { LEXICON_VAULT } from '../data/enterpriseData.ts';
import { LexiconFlashcard } from '../types/index.ts';
import { speakText } from '../utils/audioUtils.ts';

export const JargonVault: React.FC = () => {
  const [cards, setCards] = useState<LexiconFlashcard[]>(LEXICON_VAULT);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedIndustry, setSelectedIndustry] = useState<string>('All');
  const [selectedLanguage, setSelectedLanguage] = useState<string>('All');
  const [activeFlippedId, setActiveFlippedId] = useState<string | null>(null);

  const industries = ['All', 'Executive Boardroom', 'Enterprise Legal', 'Strategic Partnerships', 'FinTech Regulation', 'Deal Making'];
  const languages = ['All', 'Japanese', 'German', 'Mandarin', 'Spanish'];

  const filteredCards = cards.filter((card) => {
    const matchesSearch =
      card.term.toLowerCase().includes(searchQuery.toLowerCase()) ||
      card.translation.toLowerCase().includes(searchQuery.toLowerCase()) ||
      card.industry.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesIndustry = selectedIndustry === 'All' || card.industry === selectedIndustry;
    const matchesLanguage = selectedLanguage === 'All' || card.targetLanguage === selectedLanguage;
    return matchesSearch && matchesIndustry && matchesLanguage;
  });

  const toggleMastered = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setCards((prev) =>
      prev.map((c) => (c.id === id ? { ...c, mastered: !c.mastered } : c))
    );
  };

  const playCardAudio = (card: LexiconFlashcard, e: React.MouseEvent) => {
    e.stopPropagation();
    speakText(card.term, card.targetLanguage);
  };

  const masteredCount = cards.filter((c) => c.mastered).length;
  const progressPercent = Math.round((masteredCount / cards.length) * 100);

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="rounded-2xl border border-slate-800 bg-slate-900/60 p-6 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-indigo-400 font-semibold text-xs uppercase tracking-wider mb-1">
            <BookOpen className="h-4 w-4" />
            Proprietary Enterprise Lexicon Vault
          </div>
          <h2 className="text-xl font-bold text-white">
            Industry Jargon & High-Context Corporate Phrasing
          </h2>
          <p className="text-xs text-slate-400 mt-1 max-w-2xl">
            Enterprise language fluency is defined by mastering the exact contractual, regulatory, and cultural vocabulary used in cross-border commerce.
          </p>
        </div>

        {/* Progress Tracker */}
        <div className="bg-slate-950/80 p-4 rounded-xl border border-slate-800 min-w-[220px]">
          <div className="flex items-center justify-between text-xs mb-1.5">
            <span className="text-slate-400 font-medium">Enterprise Mastery</span>
            <span className="font-bold text-emerald-400">{progressPercent}%</span>
          </div>
          <div className="h-2 w-full rounded-full bg-slate-800 overflow-hidden">
            <div
              className="h-full bg-gradient-to-r from-indigo-500 to-emerald-400 transition-all duration-500 rounded-full"
              style={{ width: `${progressPercent}%` }}
            />
          </div>
          <div className="flex items-center justify-between text-[10px] text-slate-500 mt-1.5">
            <span>{masteredCount} Mastered</span>
            <span>{cards.length} Total Terms</span>
          </div>
        </div>
      </div>

      {/* Filter and Search Controls */}
      <div className="rounded-xl border border-slate-800 bg-slate-900/70 p-4 flex flex-col md:flex-row gap-4 items-center justify-between">
        <div className="relative w-full md:w-80">
          <Search className="h-4 w-4 text-slate-500 absolute left-3 top-2.5" />
          <input
            type="text"
            placeholder="Search enterprise terms, clauses, or translations..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-9 pr-4 py-2 text-xs rounded-xl bg-slate-950 border border-slate-800 text-slate-200 placeholder-slate-500 focus:outline-none focus:border-indigo-500"
          />
        </div>

        <div className="flex flex-wrap items-center gap-3 w-full md:w-auto">
          {/* Language filter */}
          <div className="flex items-center gap-1.5 text-xs text-slate-400">
            <span>Language:</span>
            <select
              value={selectedLanguage}
              onChange={(e) => setSelectedLanguage(e.target.value)}
              className="bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-1.5 text-xs text-slate-200 focus:outline-none focus:border-indigo-500"
            >
              {languages.map((l) => (
                <option key={l} value={l}>
                  {l}
                </option>
              ))}
            </select>
          </div>

          {/* Industry filter */}
          <div className="flex items-center gap-1.5 text-xs text-slate-400">
            <span>Domain:</span>
            <select
              value={selectedIndustry}
              onChange={(e) => setSelectedIndustry(e.target.value)}
              className="bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-1.5 text-xs text-slate-200 focus:outline-none focus:border-indigo-500"
            >
              {industries.map((ind) => (
                <option key={ind} value={ind}>
                  {ind}
                </option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {filteredCards.map((card) => {
          const isFlipped = activeFlippedId === card.id;
          return (
            <div
              key={card.id}
              onClick={() => setActiveFlippedId(isFlipped ? null : card.id)}
              className="group cursor-pointer rounded-2xl border border-slate-800 bg-slate-900/80 p-5 shadow-xl hover:border-indigo-500/50 hover:bg-slate-850/80 transition-all flex flex-col justify-between relative"
            >
              {/* Top Meta info */}
              <div>
                <div className="flex items-center justify-between gap-2 mb-3">
                  <span className="text-[10px] font-bold text-indigo-400 uppercase tracking-wider bg-indigo-500/10 px-2 py-0.5 rounded border border-indigo-500/20">
                    {card.targetLanguage} • {card.industry}
                  </span>

                  <div className="flex items-center gap-2">
                    <button
                      onClick={(e) => playCardAudio(card, e)}
                      className="p-1 text-slate-400 hover:text-indigo-300 rounded hover:bg-slate-800 transition-colors"
                      title="Listen to native voice"
                    >
                      <Volume2 className="h-4 w-4" />
                    </button>
                    <button
                      onClick={(e) => toggleMastered(card.id, e)}
                      className={`p-1 rounded transition-colors ${
                        card.mastered
                          ? 'text-emerald-400 hover:text-emerald-300'
                          : 'text-slate-600 hover:text-slate-400'
                      }`}
                      title={card.mastered ? 'Mastered' : 'Mark as mastered'}
                    >
                      <CheckCircle2 className="h-4 w-4" />
                    </button>
                  </div>
                </div>

                {/* Term & Phonetic */}
                <h3 className="text-xl font-bold text-white tracking-tight group-hover:text-indigo-200 transition-colors">
                  {card.term}
                </h3>
                {card.phonetic && (
                  <p className="text-xs text-slate-400 font-mono mt-0.5">{card.phonetic}</p>
                )}

                <div className="mt-3 pt-3 border-t border-slate-800/80">
                  <span className="text-[10px] text-slate-400 uppercase tracking-wider font-semibold block mb-0.5">
                    Corporate English Meaning:
                  </span>
                  <p className="text-sm font-semibold text-indigo-300">
                    {card.translation}
                  </p>
                </div>

                {/* Context Sentence */}
                <div className="mt-3 bg-slate-950/70 p-3 rounded-xl border border-slate-850 text-xs space-y-1">
                  <p className="font-medium text-slate-200 leading-relaxed">{card.contextSentence}</p>
                  <p className="text-slate-400 italic text-[11px]">"{card.contextTranslation}"</p>
                </div>
              </div>

              {/* Executive Strategy Tip */}
              <div className="mt-4 pt-3 border-t border-slate-800/80 flex items-start gap-2 text-xs text-amber-300/90 bg-amber-500/5 p-2.5 rounded-lg border border-amber-500/10">
                <Lightbulb className="h-4 w-4 text-amber-400 shrink-0 mt-0.5" />
                <p className="text-[11px] leading-relaxed">
                  <strong className="text-amber-300">C-Suite Tip:</strong> {card.executiveTip}
                </p>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
