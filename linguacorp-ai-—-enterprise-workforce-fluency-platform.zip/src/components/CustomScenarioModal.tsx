import React, { useState } from 'react';
import {
  Sparkles,
  X,
  Building,
  Target,
  Globe,
  Sliders,
  CheckCircle2,
  AlertCircle,
  Loader2,
} from 'lucide-react';
import { generateCustomScenarioWithAI } from '../services/geminiService.ts';
import { EnterpriseScenario } from '../types/index.ts';

interface CustomScenarioModalProps {
  isOpen: boolean;
  onClose: () => void;
  onScenarioCreated: (scenario: EnterpriseScenario) => void;
}

export const CustomScenarioModal: React.FC<CustomScenarioModalProps> = ({
  isOpen,
  onClose,
  onScenarioCreated,
}) => {
  const [industry, setIndustry] = useState('Tech & Cloud SaaS');
  const [targetLanguage, setTargetLanguage] = useState('Japanese');
  const [difficulty, setDifficulty] = useState('C1 Executive');
  const [counterpartRole, setCounterpartRole] = useState('Chief Procurement Officer');
  const [businessGoal, setBusinessGoal] = useState(
    'Defend a 12% price premium against an aggressive domestic rival while locking in a 3-year term'
  );
  const [isGenerating, setIsGenerating] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsGenerating(true);
    setErrorMessage(null);

    try {
      const newScenario = await generateCustomScenarioWithAI({
        industry,
        targetLanguage,
        difficulty,
        counterpartRole,
        businessGoal,
      });

      onScenarioCreated(newScenario);
      onClose();
    } catch (err: any) {
      console.error(err);
      setErrorMessage(err.message || 'Failed to generate scenario. Please try again.');
    } finally {
      setIsGenerating(false);
    }
  };

  const industries = [
    'Tech & Cloud SaaS',
    'FinTech & Banking',
    'BioPharma & MedTech',
    'Global Supply Chain',
    'M&A & Corporate Legal',
    'Aerospace & Heavy Industry',
  ];

  const languages = ['Japanese', 'German', 'Mandarin', 'Business English', 'Spanish', 'French'];
  const levels = ['B2 Professional', 'C1 Executive', 'C2 Mastery'];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="relative w-full max-w-xl rounded-2xl border border-indigo-500/30 bg-slate-900 p-6 shadow-2xl space-y-5">
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-800">
          <div className="flex items-center gap-2.5">
            <div className="h-9 w-9 rounded-xl bg-indigo-500/20 border border-indigo-500/30 flex items-center justify-center text-indigo-400">
              <Sparkles className="h-5 w-5" />
            </div>
            <div>
              <h3 className="font-bold text-white text-base">Generate Enterprise Scenario</h3>
              <p className="text-xs text-slate-400">Powered by Gemini AI Enterprise Model</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 text-slate-400 hover:text-slate-200 rounded-lg transition-colors"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="space-y-4 text-xs">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="text-slate-300 font-semibold block mb-1.5">
                Target Industry Sector:
              </label>
              <select
                value={industry}
                onChange={(e) => setIndustry(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-100 focus:outline-none focus:border-indigo-500"
              >
                {industries.map((ind) => (
                  <option key={ind} value={ind}>
                    {ind}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="text-slate-300 font-semibold block mb-1.5">
                Target Language:
              </label>
              <select
                value={targetLanguage}
                onChange={(e) => setTargetLanguage(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-100 focus:outline-none focus:border-indigo-500"
              >
                {languages.map((l) => (
                  <option key={l} value={l}>
                    {l}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="text-slate-300 font-semibold block mb-1.5">
                CEFR Fluency Benchmark:
              </label>
              <select
                value={difficulty}
                onChange={(e) => setDifficulty(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-100 focus:outline-none focus:border-indigo-500"
              >
                {levels.map((lvl) => (
                  <option key={lvl} value={lvl}>
                    {lvl}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="text-slate-300 font-semibold block mb-1.5">
                Counterpart Persona & Role:
              </label>
              <input
                type="text"
                value={counterpartRole}
                onChange={(e) => setCounterpartRole(e.target.value)}
                placeholder="e.g. Managing Director of Global Sourcing"
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-100 focus:outline-none focus:border-indigo-500"
              />
            </div>
          </div>

          <div>
            <label className="text-slate-300 font-semibold block mb-1.5">
              High-Stakes Commercial Objective:
            </label>
            <textarea
              rows={3}
              value={businessGoal}
              onChange={(e) => setBusinessGoal(e.target.value)}
              placeholder="Describe the deal parameters, hidden constraints, and what the user must defend..."
              className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-slate-100 focus:outline-none focus:border-indigo-500 leading-relaxed"
            />
          </div>

          {errorMessage && (
            <div className="p-3 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-300 flex items-center gap-2">
              <AlertCircle className="h-4 w-4 shrink-0 text-rose-400" />
              <span>{errorMessage}</span>
            </div>
          )}

          <div className="pt-3 border-t border-slate-800 flex items-center justify-end gap-3">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl text-slate-400 hover:text-slate-200 transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isGenerating}
              className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-gradient-to-r from-indigo-500 to-indigo-600 text-white font-semibold shadow-lg shadow-indigo-600/20 hover:from-indigo-600 hover:to-indigo-700 disabled:opacity-50 transition-all"
            >
              {isGenerating ? (
                <>
                  <Loader2 className="h-4 w-4 animate-spin" />
                  <span>Synthesizing Enterprise Scenario...</span>
                </>
              ) : (
                <>
                  <Sparkles className="h-4 w-4" />
                  <span>Generate & Launch Simulation</span>
                </>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
