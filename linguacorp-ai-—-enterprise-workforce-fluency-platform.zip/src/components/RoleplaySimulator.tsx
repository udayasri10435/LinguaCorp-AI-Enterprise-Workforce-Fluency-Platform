import React, { useState, useEffect, useRef } from 'react';
import {
  Mic,
  MicOff,
  Send,
  Volume2,
  VolumeX,
  Sparkles,
  Award,
  AlertCircle,
  Lightbulb,
  CheckCircle2,
  BookOpen,
  Info,
  RotateCcw,
  Zap,
  Globe,
  ArrowRight,
  ShieldAlert,
} from 'lucide-react';
import { EnterpriseScenario, DialogTurn, EvaluationResult } from '../types/index.ts';
import { sendTutorMessage } from '../services/geminiService.ts';
import { speakText, stopSpeaking, createSpeechRecognizer, isSpeechRecognitionSupported } from '../utils/audioUtils.ts';

interface RoleplaySimulatorProps {
  scenario: EnterpriseScenario;
  onScenarioComplete?: (score: number) => void;
  soundEnabled: boolean;
}

export const RoleplaySimulator: React.FC<RoleplaySimulatorProps> = ({
  scenario,
  onScenarioComplete,
  soundEnabled,
}) => {
  const [conversation, setConversation] = useState<DialogTurn[]>([]);
  const [inputMessage, setInputMessage] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [latestEvaluation, setLatestEvaluation] = useState<EvaluationResult | null>(null);
  const [showTranslations, setShowTranslations] = useState(true);
  const [isListening, setIsListening] = useState(false);
  const [activeAudioTurnId, setActiveAudioTurnId] = useState<string | null>(null);
  const [micSupported, setMicSupported] = useState(true);

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const speechRecognizerRef = useRef<any>(null);

  // Initialize conversation with the scenario's opening challenge
  useEffect(() => {
    const initialTurn: DialogTurn = {
      id: `turn-init-${scenario.id}`,
      sender: 'ai',
      text: scenario.initialCounterpartMessage,
      translation: scenario.initialTranslation,
      timestamp: 'Just now',
      audioTone: 'analytical',
      evaluation: undefined,
    };
    setConversation([initialTurn]);
    setLatestEvaluation(null);
    setInputMessage('');
    stopSpeaking();

    // Auto-play opening line if sound is enabled
    if (soundEnabled) {
      speakText(scenario.initialCounterpartMessage, scenario.targetLanguage, () => {
        setActiveAudioTurnId(null);
      });
      setActiveAudioTurnId(initialTurn.id);
    }

    setMicSupported(isSpeechRecognitionSupported());

    return () => {
      stopSpeaking();
      if (speechRecognizerRef.current) {
        speechRecognizerRef.current.stop();
      }
    };
  }, [scenario.id]);

  // Auto-scroll to bottom of conversation
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [conversation, isSubmitting]);

  const handleSendMessage = async (textToSend?: string) => {
    const message = (textToSend || inputMessage).trim();
    if (!message || isSubmitting) return;

    if (isListening && speechRecognizerRef.current) {
      speechRecognizerRef.current.stop();
      setIsListening(false);
    }

    const userTurn: DialogTurn = {
      id: `turn-user-${Date.now()}`,
      sender: 'user',
      text: message,
      timestamp: 'Just now',
    };

    const newHistory = [...conversation, userTurn];
    setConversation(newHistory);
    setInputMessage('');
    setIsSubmitting(true);

    try {
      const response = await sendTutorMessage({
        scenario,
        conversationHistory: newHistory,
        userMessage: message,
      });

      const aiTurn: DialogTurn = {
        id: `turn-ai-${Date.now()}`,
        sender: 'ai',
        text: response.reply,
        translation: response.replyTranslation,
        timestamp: 'Just now',
        audioTone: response.audioTone,
        evaluation: response.evaluation,
      };

      setConversation((prev) => [...prev, aiTurn]);
      setLatestEvaluation(response.evaluation);

      if (soundEnabled && response.reply) {
        setActiveAudioTurnId(aiTurn.id);
        speakText(response.reply, scenario.targetLanguage, () => {
          setActiveAudioTurnId(null);
        });
      }

      if (onScenarioComplete && response.evaluation?.overallScore) {
        onScenarioComplete(response.evaluation.overallScore);
      }
    } catch (err) {
      console.error('Failed to get tutor response:', err);
    } finally {
      setIsSubmitting(false);
    }
  };

  const toggleMic = () => {
    if (isListening) {
      if (speechRecognizerRef.current) {
        speechRecognizerRef.current.stop();
      }
      setIsListening(false);
    } else {
      const recognizer = createSpeechRecognizer(
        scenario.targetLanguage,
        (transcript) => {
          setInputMessage(transcript);
        },
        (error) => {
          console.warn('Speech error:', error);
          setIsListening(false);
        },
        (listening) => {
          setIsListening(listening);
        }
      );

      if (recognizer) {
        speechRecognizerRef.current = recognizer;
        recognizer.start();
      }
    }
  };

  const playTurnAudio = (turnId: string, text: string) => {
    if (activeAudioTurnId === turnId) {
      stopSpeaking();
      setActiveAudioTurnId(null);
      return;
    }

    setActiveAudioTurnId(turnId);
    speakText(text, scenario.targetLanguage, () => {
      setActiveAudioTurnId(null);
    });
  };

  const handleResetConversation = () => {
    stopSpeaking();
    const initialTurn: DialogTurn = {
      id: `turn-init-${scenario.id}-${Date.now()}`,
      sender: 'ai',
      text: scenario.initialCounterpartMessage,
      translation: scenario.initialTranslation,
      timestamp: 'Just now',
      audioTone: 'analytical',
    };
    setConversation([initialTurn]);
    setLatestEvaluation(null);
    setInputMessage('');
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
      {/* Left Sidebar: Counterpart Dossier & Cultural Protocol */}
      <div className="lg:col-span-3 space-y-4">
        {/* Counterpart Dossier Card */}
        <div className="rounded-2xl border border-slate-800 bg-slate-900/70 p-5 shadow-xl">
          <div className="flex items-center gap-2 mb-3 text-xs font-semibold text-slate-400 uppercase tracking-wider">
            <Globe className="h-3.5 w-3.5 text-indigo-400" />
            Counterpart Dossier
          </div>

          <div className="flex items-start gap-4">
            <img
              src={scenario.counterpart.avatar}
              alt={scenario.counterpart.name}
              className="h-14 w-14 rounded-xl object-cover border-2 border-indigo-500/30 shadow-md"
            />
            <div>
              <h3 className="font-bold text-white text-base leading-tight">
                {scenario.counterpart.name}
              </h3>
              <p className="text-xs text-indigo-300 font-medium">{scenario.counterpart.title}</p>
              <p className="text-[11px] text-slate-400">{scenario.counterpart.company}</p>
            </div>
          </div>

          <div className="mt-4 pt-3 border-t border-slate-800 text-xs">
            <span className="text-slate-400 font-medium">Negotiation Persona:</span>
            <p className="text-slate-300 mt-1 italic text-[11px] leading-relaxed">
              "{scenario.counterpart.personality}"
            </p>
          </div>
        </div>

        {/* Business Context & Hidden Stakes */}
        <div className="rounded-2xl border border-slate-800 bg-slate-900/70 p-5 shadow-xl space-y-3">
          <div className="flex items-center gap-2 text-xs font-semibold text-amber-400 uppercase tracking-wider">
            <ShieldAlert className="h-3.5 w-3.5" />
            High-Stakes Commercial Context
          </div>

          <p className="text-xs text-slate-300 leading-relaxed">
            {scenario.businessContext}
          </p>

          <div className="rounded-xl border border-amber-500/20 bg-amber-500/5 p-3">
            <p className="text-[11px] font-semibold text-amber-300 mb-1">Bottom-Line Constraint:</p>
            <p className="text-[11px] text-slate-300 leading-normal">
              {scenario.hiddenStakes}
            </p>
          </div>

          <div className="pt-2 border-t border-slate-800">
            <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider flex items-center gap-1.5 mb-2">
              <Lightbulb className="h-3.5 w-3.5 text-yellow-400" />
              Cultural Protocol
            </span>
            <p className="text-xs text-slate-300 leading-relaxed bg-slate-950/60 p-2.5 rounded-lg border border-slate-850">
              {scenario.culturalProtocol}
            </p>
          </div>
        </div>

        {/* Learning Objectives */}
        <div className="rounded-2xl border border-slate-800 bg-slate-900/70 p-5 shadow-xl">
          <div className="flex items-center gap-2 text-xs font-semibold text-slate-400 uppercase tracking-wider mb-3">
            <CheckCircle2 className="h-3.5 w-3.5 text-emerald-400" />
            Executive Competencies Tested
          </div>
          <ul className="space-y-2">
            {scenario.learningObjectives.map((obj, i) => (
              <li key={i} className="text-xs text-slate-300 flex items-start gap-2">
                <span className="h-1.5 w-1.5 rounded-full bg-indigo-400 mt-1.5 shrink-0" />
                <span>{obj}</span>
              </li>
            ))}
          </ul>
        </div>
      </div>

      {/* Center: Interactive AI Dialogue Simulator */}
      <div className="lg:col-span-6 flex flex-col h-[740px] rounded-2xl border border-slate-800 bg-slate-900/90 shadow-2xl overflow-hidden">
        {/* Chat Header */}
        <div className="px-5 py-3.5 border-b border-slate-800 bg-slate-950/80 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="relative">
              <img
                src={scenario.counterpart.avatar}
                alt={scenario.counterpart.name}
                className="h-9 w-9 rounded-full object-cover border border-indigo-500/40"
              />
              <span className="absolute bottom-0 right-0 h-2.5 w-2.5 rounded-full bg-emerald-500 ring-2 ring-slate-950" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-semibold text-white text-sm">
                  {scenario.counterpart.name}
                </span>
                <span className="rounded bg-indigo-500/10 px-1.5 py-0.5 text-[10px] font-medium text-indigo-300 border border-indigo-500/20">
                  {scenario.targetLanguage} • {scenario.level}
                </span>
              </div>
              <p className="text-[11px] text-slate-400">Live Enterprise Simulation Session</p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setShowTranslations(!showTranslations)}
              className={`text-xs px-2.5 py-1 rounded-lg border transition-all ${
                showTranslations
                  ? 'border-indigo-500/30 bg-indigo-500/10 text-indigo-300'
                  : 'border-slate-800 text-slate-400 hover:text-slate-200'
              }`}
              title="Toggle English translations"
            >
              EN Subtitles {showTranslations ? 'ON' : 'OFF'}
            </button>
            <button
              onClick={handleResetConversation}
              className="p-1.5 text-slate-400 hover:text-slate-200 hover:bg-slate-800 rounded-lg transition-colors"
              title="Restart Scenario"
            >
              <RotateCcw className="h-4 w-4" />
            </button>
          </div>
        </div>

        {/* Message Stream */}
        <div className="flex-1 overflow-y-auto p-5 space-y-4">
          {conversation.map((turn) => {
            const isUser = turn.sender === 'user';
            return (
              <div
                key={turn.id}
                className={`flex gap-3 ${isUser ? 'justify-end' : 'justify-start'}`}
              >
                {!isUser && (
                  <img
                    src={scenario.counterpart.avatar}
                    alt={scenario.counterpart.name}
                    className="h-8 w-8 rounded-full object-cover shrink-0 mt-1 border border-slate-700"
                  />
                )}

                <div
                  className={`max-w-[85%] rounded-2xl p-4 transition-all ${
                    isUser
                      ? 'bg-indigo-600 text-white rounded-tr-none shadow-lg shadow-indigo-600/10'
                      : 'bg-slate-800/90 text-slate-100 rounded-tl-none border border-slate-700/60'
                  }`}
                >
                  <div className="flex items-center justify-between gap-4 mb-1">
                    <span className="text-[10px] font-medium opacity-70">
                      {isUser ? 'You (Enterprise Executive)' : scenario.counterpart.name}
                    </span>
                    {!isUser && (
                      <button
                        onClick={() => playTurnAudio(turn.id, turn.text)}
                        className={`text-slate-400 hover:text-indigo-300 p-0.5 rounded transition-colors ${
                          activeAudioTurnId === turn.id ? 'text-indigo-400 animate-pulse' : ''
                        }`}
                        title="Listen to native pronunciation"
                      >
                        <Volume2 className="h-3.5 w-3.5" />
                      </button>
                    )}
                  </div>

                  <p className="text-sm font-medium leading-relaxed tracking-normal">
                    {turn.text}
                  </p>

                  {/* Subtitle translation */}
                  {showTranslations && turn.translation && (
                    <div className="mt-2 pt-2 border-t border-white/10 text-xs text-slate-300/80 italic font-normal">
                      "{turn.translation}"
                    </div>
                  )}

                  {/* Turn Quick Evaluation Badge */}
                  {turn.evaluation && (
                    <div className="mt-2.5 pt-2 border-t border-white/10 flex items-center gap-2 text-[11px]">
                      <span className="flex items-center gap-1 font-semibold text-emerald-300">
                        <Award className="h-3 w-3" />
                        Score: {turn.evaluation.overallScore}/100
                      </span>
                      <span className="text-slate-400">•</span>
                      <span className="text-indigo-200">
                        Tone: {turn.evaluation.tone}
                      </span>
                    </div>
                  )}
                </div>

                {isUser && (
                  <div className="h-8 w-8 rounded-full bg-gradient-to-tr from-indigo-500 to-indigo-700 flex items-center justify-center text-xs font-bold text-white shrink-0 mt-1 shadow-md">
                    ER
                  </div>
                )}
              </div>
            );
          })}

          {isSubmitting && (
            <div className="flex gap-3 items-center text-slate-400 text-xs pl-2">
              <img
                src={scenario.counterpart.avatar}
                alt={scenario.counterpart.name}
                className="h-8 w-8 rounded-full object-cover border border-slate-700 animate-pulse"
              />
              <div className="rounded-2xl rounded-tl-none bg-slate-800/60 border border-slate-700/40 px-4 py-2.5 flex items-center gap-2 text-slate-300">
                <span className="relative flex h-2 w-2">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-indigo-400 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-2 w-2 bg-indigo-500"></span>
                </span>
                <span>{scenario.counterpart.name} is evaluating your response...</span>
              </div>
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>

        {/* Suggested Enterprise Replies Deck */}
        <div className="p-3 bg-slate-950/90 border-t border-slate-850">
          <div className="flex items-center gap-2 mb-2 text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
            <Zap className="h-3 w-3 text-amber-400" />
            Quick Executive Response Options (Click to load)
          </div>
          <div className="grid grid-cols-1 gap-1.5 max-h-24 overflow-y-auto pr-1">
            {scenario.suggestedReplies.map((reply, idx) => (
              <button
                key={idx}
                onClick={() => setInputMessage(reply.text)}
                className="text-left text-xs bg-slate-900/90 hover:bg-slate-850 border border-slate-800 hover:border-indigo-500/40 p-2 rounded-xl transition-all flex items-center justify-between group"
              >
                <div className="truncate pr-2">
                  <span className="text-[10px] font-semibold text-indigo-400 uppercase tracking-wider mr-2">
                    [{reply.type}]
                  </span>
                  <span className="text-slate-300 group-hover:text-white font-medium">
                    {reply.text}
                  </span>
                </div>
                <ArrowRight className="h-3.5 w-3.5 text-slate-500 group-hover:text-indigo-400 shrink-0" />
              </button>
            ))}
          </div>
        </div>

        {/* User Input & Audio Bar */}
        <div className="p-3 bg-slate-950 border-t border-slate-800">
          <form
            onSubmit={(e) => {
              e.preventDefault();
              handleSendMessage();
            }}
            className="flex items-center gap-2"
          >
            {micSupported && (
              <button
                type="button"
                onClick={toggleMic}
                className={`p-2.5 rounded-xl border transition-all ${
                  isListening
                    ? 'bg-rose-500 text-white border-rose-400 animate-pulse shadow-lg shadow-rose-500/30'
                    : 'bg-slate-900 text-slate-400 border-slate-800 hover:text-slate-200 hover:bg-slate-850'
                }`}
                title={isListening ? 'Stop recording voice' : 'Speak with microphone'}
              >
                {isListening ? <MicOff className="h-4 w-4" /> : <Mic className="h-4 w-4" />}
              </button>
            )}

            <div className="relative flex-1">
              <input
                type="text"
                value={inputMessage}
                onChange={(e) => setInputMessage(e.target.value)}
                placeholder={
                  isListening
                    ? 'Listening to speech in target language...'
                    : `Type or speak in ${scenario.targetLanguage}...`
                }
                className="w-full rounded-xl border border-slate-800 bg-slate-900/90 px-4 py-2.5 text-sm text-slate-100 placeholder-slate-500 focus:border-indigo-500 focus:outline-none focus:ring-1 focus:ring-indigo-500"
              />
              {isListening && (
                <span className="absolute right-3 top-2.5 flex h-2.5 w-2.5">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-rose-400 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-rose-500"></span>
                </span>
              )}
            </div>

            <button
              type="submit"
              disabled={!inputMessage.trim() || isSubmitting}
              className="flex items-center justify-center rounded-xl bg-indigo-600 px-4 py-2.5 text-sm font-semibold text-white shadow-md shadow-indigo-600/20 hover:bg-indigo-500 disabled:opacity-50 disabled:cursor-not-allowed transition-all"
            >
              <Send className="h-4 w-4" />
            </button>
          </form>
        </div>
      </div>

      {/* Right Sidebar: Real-Time Gemini Executive Evaluation & Rephrase */}
      <div className="lg:col-span-3 space-y-4">
        {latestEvaluation ? (
          <div className="rounded-2xl border border-indigo-500/30 bg-slate-900/80 p-5 shadow-2xl space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div className="flex items-center gap-2">
                <Sparkles className="h-4 w-4 text-indigo-400" />
                <h3 className="font-bold text-white text-sm">AI Executive Debrief</h3>
              </div>
              <span className="rounded-md bg-indigo-500/20 border border-indigo-500/30 px-2 py-0.5 text-xs font-bold text-indigo-300">
                {latestEvaluation.cefrDetected} CEFR
              </span>
            </div>

            {/* Score & Tone */}
            <div className="grid grid-cols-2 gap-3">
              <div className="rounded-xl bg-slate-950/70 p-3 border border-slate-850">
                <span className="text-[10px] text-slate-400 uppercase tracking-wider font-semibold">
                  Gravitas Score
                </span>
                <div className="flex items-baseline gap-1 mt-1">
                  <span className="text-2xl font-black text-emerald-400">
                    {latestEvaluation.overallScore}
                  </span>
                  <span className="text-xs text-slate-500">/ 100</span>
                </div>
              </div>

              <div className="rounded-xl bg-slate-950/70 p-3 border border-slate-850">
                <span className="text-[10px] text-slate-400 uppercase tracking-wider font-semibold">
                  Tone Alignment
                </span>
                <div className="flex items-baseline gap-1 mt-1">
                  <span className="text-2xl font-black text-indigo-400">
                    {latestEvaluation.toneScore}%
                  </span>
                </div>
              </div>
            </div>

            {/* Executive Rephrase Coach */}
            <div className="rounded-xl border border-indigo-500/30 bg-indigo-500/5 p-3.5 space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-indigo-300 flex items-center gap-1.5">
                  <Sparkles className="h-3.5 w-3.5 text-indigo-400" />
                  Say it like a Fortune 500 VP
                </span>
                <button
                  onClick={() => {
                    speakText(latestEvaluation.executiveRephrase, scenario.targetLanguage);
                  }}
                  className="text-indigo-400 hover:text-indigo-300 text-[11px] flex items-center gap-1"
                  title="Listen to native voice"
                >
                  <Volume2 className="h-3 w-3" />
                  Listen
                </button>
              </div>
              <p className="text-xs font-medium text-slate-100 leading-relaxed bg-slate-950/60 p-2.5 rounded-lg border border-slate-800">
                "{latestEvaluation.executiveRephrase}"
              </p>
            </div>

            {/* Cultural Nuance Flag */}
            <div className="rounded-xl border border-amber-500/20 bg-amber-500/5 p-3 space-y-1.5">
              <span className="text-[11px] font-bold text-amber-300 flex items-center gap-1.5">
                <Info className="h-3.5 w-3.5" />
                Cross-Cultural Pragmatics
              </span>
              <p className="text-xs text-slate-300 leading-relaxed">
                {latestEvaluation.culturalNuance}
              </p>
            </div>

            {/* Strengths & Improvements */}
            <div className="space-y-3 pt-2">
              <div>
                <span className="text-[11px] font-semibold text-emerald-400 flex items-center gap-1 mb-1">
                  <CheckCircle2 className="h-3 w-3" /> Strengths
                </span>
                <ul className="text-xs text-slate-300 space-y-1 pl-4 list-disc marker:text-emerald-500">
                  {latestEvaluation.strengths.map((str, idx) => (
                    <li key={idx}>{str}</li>
                  ))}
                </ul>
              </div>

              <div>
                <span className="text-[11px] font-semibold text-indigo-300 flex items-center gap-1 mb-1">
                  <AlertCircle className="h-3 w-3" /> Tactical Polish
                </span>
                <ul className="text-xs text-slate-300 space-y-1 pl-4 list-disc marker:text-indigo-500">
                  {latestEvaluation.improvements.map((imp, idx) => (
                    <li key={idx}>{imp}</li>
                  ))}
                </ul>
              </div>
            </div>

            {/* Key Vocabulary Learned in this turn */}
            {latestEvaluation.keyVocabulary?.length > 0 && (
              <div className="pt-2 border-t border-slate-800">
                <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider flex items-center gap-1 mb-2">
                  <BookOpen className="h-3 w-3 text-indigo-400" />
                  Key Enterprise Jargon
                </span>
                <div className="space-y-2">
                  {latestEvaluation.keyVocabulary.map((voc, i) => (
                    <div key={i} className="bg-slate-950/80 p-2.5 rounded-lg border border-slate-850 text-xs">
                      <div className="font-bold text-indigo-300">{voc.term}</div>
                      <div className="text-[11px] text-slate-300 mt-0.5">{voc.definition}</div>
                      {voc.example && (
                        <div className="text-[10px] text-slate-400 italic mt-1 border-t border-slate-850 pt-1">
                          Ex: {voc.example}
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        ) : (
          /* Empty state before first response */
          <div className="rounded-2xl border border-slate-800 bg-slate-900/60 p-6 text-center space-y-3">
            <div className="h-12 w-12 rounded-2xl bg-indigo-500/10 border border-indigo-500/20 text-indigo-400 flex items-center justify-center mx-auto">
              <Sparkles className="h-6 w-6" />
            </div>
            <h4 className="font-semibold text-white text-sm">Real-Time AI Debrief Ready</h4>
            <p className="text-xs text-slate-400 leading-relaxed">
              Send your first response or select a suggested executive reply to receive instant CEFR scoring, gravitas analysis, and high-stakes rephrasing.
            </p>
          </div>
        )}

        {/* Target Track Quick Reference */}
        <div className="rounded-2xl border border-slate-800 bg-slate-900/60 p-4">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span>CEFR Target: <strong className="text-white">{scenario.level} Mastery</strong></span>
            <span>Duration: <strong className="text-white">{scenario.estimatedMinutes} min</strong></span>
          </div>
        </div>
      </div>
    </div>
  );
};
