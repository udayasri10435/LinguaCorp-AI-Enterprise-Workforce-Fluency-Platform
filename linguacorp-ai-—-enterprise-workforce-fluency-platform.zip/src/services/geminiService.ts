import { DialogTurn, EvaluationResult, EnterpriseScenario } from '../types/index.ts';

export interface SendTutorMessageParams {
  scenario: EnterpriseScenario;
  conversationHistory: DialogTurn[];
  userMessage: string;
}

export interface TutorResponse {
  reply: string;
  replyTranslation?: string;
  audioTone?: string;
  evaluation: EvaluationResult;
}

export async function sendTutorMessage(params: SendTutorMessageParams): Promise<TutorResponse> {
  const { scenario, conversationHistory, userMessage } = params;

  try {
    const res = await fetch('/api/tutor/chat', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        scenarioTitle: scenario.title,
        counterpartName: scenario.counterpart.name,
        counterpartRole: scenario.counterpart.title,
        companyContext: scenario.counterpart.company,
        targetLanguage: scenario.targetLanguage,
        targetLevel: scenario.level,
        conversationHistory: conversationHistory.map((t) => ({
          sender: t.sender,
          text: t.text,
        })),
        userMessage,
        specialInstruction: scenario.culturalProtocol,
      }),
    });

    if (!res.ok) {
      throw new Error(`Server returned ${res.status}`);
    }

    const data = await res.json();
    if (data.reply && data.evaluation) {
      return data;
    }
    throw new Error('Invalid response structure');
  } catch (err) {
    console.warn('Falling back to local AI engine:', err);
    return getLocalSimulatedResponse(scenario, userMessage);
  }
}

export async function generateCustomScenarioWithAI(params: {
  industry: string;
  difficulty: string;
  counterpartRole: string;
  businessGoal: string;
  targetLanguage: string;
}): Promise<EnterpriseScenario> {
  try {
    const res = await fetch('/api/scenario/generate', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(params),
    });

    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const data = await res.json();
    return {
      ...data,
      subtitle: `${data.level} High-Stakes Enterprise Simulation`,
      difficultyTag: 'High-Stakes Negotiation',
      estimatedMinutes: 20,
      hiddenStakes: 'Executive deal margin must be protected at all costs.',
      culturalProtocol: 'Frame all concessions within structured commercial milestones.',
    };
  } catch (err) {
    console.warn('Fallback scenario generation:', err);
    return {
      id: `custom-scen-${Date.now()}`,
      title: `${params.industry}: High-Stakes Enterprise Agreement`,
      subtitle: `${params.difficulty} Corporate Fluency Track`,
      industry: (params.industry as any) || 'Tech & Cloud SaaS',
      targetLanguage: (params.targetLanguage as any) || 'Japanese',
      level: (params.difficulty as any) || 'C1',
      difficultyTag: 'High-Stakes Negotiation',
      estimatedMinutes: 18,
      counterpart: {
        name: params.counterpartRole ? `Executive ${params.counterpartRole}` : 'Executive Partner',
        title: params.counterpartRole || 'Managing Director',
        company: 'Global Frontier Industries',
        personality: 'Analytical, formal, focused on risk minimization and ROI governance',
        avatar: 'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?auto=format&fit=crop&w=400&q=80',
        voiceGender: 'male',
      },
      businessContext: `Your enterprise is negotiating a complex international rollout. The client's investment committee has scrutinized liability boundaries and pricing structure.`,
      hiddenStakes: 'Protecting the multi-year SLA boundary without triggering an RFP disqualification.',
      learningObjectives: [
        'Formulate formal corporate pushback with regional cultural nuance',
        'Defend enterprise margins using structured value metrics',
        'Establish executive rapport without compromising legal liability caps',
      ],
      culturalProtocol: 'Acknowledge executive authority, avoid abrupt negatives, present structured trade-offs.',
      initialCounterpartMessage: params.targetLanguage === 'German'
        ? 'Wir haben Ihre Bedingungen geprüft. Aus regulatorischer Sicht können wir die vorgeschlagene Haftungsobergrenze nicht akzeptieren. Wie beabsichtigen Sie, dieses Risiko für uns zu minimieren?'
        : params.targetLanguage === 'Mandarin'
        ? '贵方的技术方案我们基本认可，但在合规审计与交付惩罚条款上，我们的法务团队仍有重大疑虑。请问贵司打算如何化解这个风险？'
        : 'ご提案いただいた内容の重要性は理解しておりますが、弊社の取締役会としてはリスクヘッジの観点から補償条項の改定を希望しております。御社の見解はいかがでしょうか？',
      initialTranslation: 'We have reviewed your proposed conditions. From a governance standpoint, our board has serious reservations regarding liability allocation. How do you intend to de-risk this for us?',
      suggestedReplies: [
        {
          type: 'Diplomatic Softening',
          text: 'ご指摘の点、誠に適切であり深く感謝申し上げます。リスクを分散しつつ相互の利益を最大化する段階的コミットメントをご提案いたします。',
          translation: 'Your point is profoundly astute, and we appreciate it deeply. We propose a phased commitment that mitigates risk while maximizing reciprocal value.',
        },
      ],
      keyVocabulary: [
        {
          term: 'リスクヘッジ (Risuku Hejji)',
          meaning: 'Risk mitigation / risk hedging',
          usage: '事業継続計画におけるリスクヘッジの徹底。',
          industry: 'Enterprise Risk',
        },
      ],
    };
  }
}

function getLocalSimulatedResponse(scenario: EnterpriseScenario, userMessage: string): TutorResponse {
  const lang = scenario.targetLanguage;

  if (lang === 'Japanese') {
    return {
      reply: 'おっしゃる意図は十分に伝わりました。しかしながら、来期の予算枠はすでに確定しており、追加の役員会承認を得るには明確な費用対効果の論拠が不可欠です。この点について、他社事例に基づいた具体的な数値指標を提示していただけますか？',
      replyTranslation: 'Your intent is fully understood. However, our next fiscal year’s budget allocation has already been finalized, and obtaining supplementary board approval will require undeniable ROI justification. Could you present concrete metrics based on peer enterprise benchmarks?',
      audioTone: 'diplomatic',
      evaluation: {
        overallScore: 89,
        cefrDetected: 'C1',
        tone: 'Executive Keigo & Diplomatic Consensus',
        toneScore: 92,
        strengths: [
          'Strong command of polite business syntax (Kenjougo)',
          'Clear strategic positioning without confrontational vocabulary',
        ],
        improvements: [
          'Preempt the competitor comparison by introducing our tier-1 SLA benchmark earlier',
        ],
        executiveRephrase: '恐縮ではございますが、御社の同業他社様における削減実績数値をまとめた比較資料を速やかに共有可能でございます。',
        culturalNuance: 'In Japanese enterprise procurement, requesting case studies (他社事例 - Tasha Jirei) is a classic invitation to provide internal political ammunition for their internal board sponsorship.',
        keyVocabulary: [
          {
            term: '費用対効果 (Hiyou Tai Kouka)',
            definition: 'Cost-effectiveness / Return on Investment (ROI)',
            example: '費用対効果を厳格に算定した上で判断を下す。',
          },
          {
            term: '他社事例 (Tasha Jirei)',
            definition: 'Peer industry case studies and precedent benchmarks',
            example: '同業他社事例をベンチマークとして参照する。',
          },
        ],
      },
    };
  }

  if (lang === 'German') {
    return {
      reply: 'Das ist ein pragmatischer Ansatz, Herr Kollege. Dennoch besteht unser Wirtschaftsprüfer auf einer verbindlichen Klausel bezüglich der Datenresidenz innerhalb der Europäischen Union. Sind Ihre Rechenzentren vollumfänglich C5- und BSI-zertifiziert?',
      replyTranslation: 'That is a pragmatic approach. Nevertheless, our statutory auditor insists on a binding clause regarding data residency within the European Union. Are your data centers comprehensively C5 and BSI certified?',
      audioTone: 'analytical',
      evaluation: {
        overallScore: 87,
        cefrDetected: 'C1',
        tone: 'Direct, Analytical German Corporate',
        toneScore: 90,
        strengths: [
          'Precise logic flow and clear boundaries',
          'Good use of formal business pronouns and concise German syntax',
        ],
        improvements: [
          'Directly cite German Cloud Computing Compliance Controls (C5) standards in the opening sentence',
        ],
        executiveRephrase: 'Selbstverständlich sind sämtliche Primär- und Backup-Systeme in Frankfurt und Nürnberg uneingeschränkt BSI C5 Typ 2 zertifiziert.',
        culturalNuance: 'German corporate auditors prioritize formal institutional certifications (BSI, TÜV, DIN) over verbal assurances.',
        keyVocabulary: [
          {
            term: 'die Datenresidenz',
            definition: 'Sovereign domestic data residency',
            example: 'Die Datenresidenz verbleibt ausnahmslos in Deutschland.',
          },
        ],
      },
    };
  }

  return {
    reply: `I appreciate your transparency on this point. However, our executive steering committee will need to see verifiable payback metrics before we greenlight the master service agreement. How do your implementation benchmarks de-risk our Q4 rollout?`,
    replyTranslation: 'Direct board-level inquiry into implementation metrics.',
    audioTone: 'analytical',
    evaluation: {
      overallScore: 88,
      cefrDetected: 'C1',
      tone: 'Strategic Boardroom English',
      toneScore: 91,
      strengths: [
        'Assertive tone with strong business vernacular',
        'Avoided passive voice when defining commercial responsibilities',
      ],
      improvements: [
        'Quantify the time-to-value milestone explicitly (e.g. "by week 6")',
      ],
      executiveRephrase: 'We guarantee a 60-day time-to-value milestone with dedicated enterprise engineering squads embedded on-site.',
      culturalNuance: 'Executive steering committees appreciate contractual accountability tied to phased milestones rather than broad promises.',
      keyVocabulary: [
        {
          term: 'Time-to-Value',
          definition: 'The elapsed duration from contract execution to measurable commercial realization',
          example: 'Our SaaS platform delivers a sub-60-day time-to-value benchmark.',
        },
      ],
    },
  };
}
