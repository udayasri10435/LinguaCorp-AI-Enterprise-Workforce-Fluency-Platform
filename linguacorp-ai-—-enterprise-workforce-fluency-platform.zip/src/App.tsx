import React, { useState } from 'react';
import { Header } from './components/Header.tsx';
import { LearnerWorkspace } from './components/LearnerWorkspace.tsx';
import { AdminAnalytics } from './components/AdminAnalytics.tsx';
import { CustomScenarioModal } from './components/CustomScenarioModal.tsx';
import { EnterpriseSalesModal } from './components/EnterpriseSalesModal.tsx';
import { ENTERPRISE_SCENARIOS } from './data/enterpriseData.ts';
import { EnterpriseScenario } from './types/index.ts';

export default function App() {
  const [currentView, setCurrentView] = useState<'learner' | 'admin'>('learner');
  const [scenarios, setScenarios] = useState<EnterpriseScenario[]>(ENTERPRISE_SCENARIOS);
  const [selectedScenario, setSelectedScenario] = useState<EnterpriseScenario>(ENTERPRISE_SCENARIOS[0]);
  const [isScenarioModalOpen, setIsScenarioModalOpen] = useState(false);
  const [isSalesModalOpen, setIsSalesModalOpen] = useState(false);
  const [soundEnabled, setSoundEnabled] = useState(true);

  const handleScenarioCreated = (newScenario: EnterpriseScenario) => {
    setScenarios((prev) => [newScenario, ...prev]);
    setSelectedScenario(newScenario);
    setCurrentView('learner');
  };

  return (
    <div className="min-h-screen bg-[#0b0f17] text-slate-100 flex flex-col font-sans selection:bg-indigo-500/30 selection:text-indigo-200">
      {/* Persistent Enterprise Header */}
      <Header
        currentView={currentView}
        onViewChange={setCurrentView}
        onOpenScenarioModal={() => setIsScenarioModalOpen(true)}
        onOpenSalesModal={() => setIsSalesModalOpen(true)}
        soundEnabled={soundEnabled}
        onToggleSound={() => setSoundEnabled(!soundEnabled)}
      />

      {/* Main Content Viewport */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 py-6 sm:py-8">
        {currentView === 'learner' ? (
          <LearnerWorkspace
            scenarios={scenarios}
            selectedScenario={selectedScenario}
            onSelectScenario={setSelectedScenario}
            onOpenCustomScenarioModal={() => setIsScenarioModalOpen(true)}
            soundEnabled={soundEnabled}
          />
        ) : (
          <AdminAnalytics />
        )}
      </main>

      {/* Enterprise Footer */}
      <footer className="border-t border-slate-800/80 bg-slate-950/80 py-6 text-xs text-slate-500">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <span className="font-semibold text-slate-400">LinguaCorp AI Enterprise</span>
            <span>•</span>
            <span>Global Workforce Language Intelligence & AI Roleplay Tutor</span>
          </div>
          <div className="flex items-center gap-4 text-slate-400">
            <button
              onClick={() => setIsSalesModalOpen(true)}
              className="hover:text-indigo-300 transition-colors"
            >
              Enterprise Procurement
            </button>
            <span>•</span>
            <span>CEFR C1/C2 Standard</span>
            <span>•</span>
            <span>SOC2 Type II Certified</span>
          </div>
        </div>
      </footer>

      {/* Modals */}
      <CustomScenarioModal
        isOpen={isScenarioModalOpen}
        onClose={() => setIsScenarioModalOpen(false)}
        onScenarioCreated={handleScenarioCreated}
      />

      <EnterpriseSalesModal
        isOpen={isSalesModalOpen}
        onClose={() => setIsSalesModalOpen(false)}
      />
    </div>
  );
}
